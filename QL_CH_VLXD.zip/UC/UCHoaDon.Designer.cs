﻿using System.Drawing;
using System.Windows.Forms;

namespace QuanLyCuaHang_VLXD.UC
{
    partial class UCHoaDon
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Designer

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblMaHD = new System.Windows.Forms.Label();
            this.txtMaHD = new System.Windows.Forms.TextBox();
            this.lblNhanVien = new System.Windows.Forms.Label();
            this.cbNhanVien = new System.Windows.Forms.ComboBox();
            this.lblKhachHang = new System.Windows.Forms.Label();
            this.cbKhachHang = new System.Windows.Forms.ComboBox();
            this.lblNgayBan = new System.Windows.Forms.Label();
            this.txtNgayBan = new System.Windows.Forms.TextBox();
            this.lblHinhThuc = new System.Windows.Forms.Label();
            this.txtHinhThuc = new System.Windows.Forms.TextBox();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.lblTimKiem = new System.Windows.Forms.Label();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.cbLoaiTim = new System.Windows.Forms.ComboBox();
            this.dgvHoaDon = new System.Windows.Forms.DataGridView();
            this.colMaHD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHoTenKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHoTenNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayBan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHinhThucTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTongTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lblTitle.Location = new System.Drawing.Point(260, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(367, 50);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ HÓA ĐƠN";
            // 
            // lblMaHD
            // 
            this.lblMaHD.Location = new System.Drawing.Point(21, 76);
            this.lblMaHD.Name = "lblMaHD";
            this.lblMaHD.Size = new System.Drawing.Size(84, 29);
            this.lblMaHD.TabIndex = 1;
            this.lblMaHD.Text = "Mã HD :";
            // 
            // txtMaHD
            // 
            this.txtMaHD.Location = new System.Drawing.Point(130, 73);
            this.txtMaHD.Multiline = true;
            this.txtMaHD.Name = "txtMaHD";
            this.txtMaHD.Size = new System.Drawing.Size(263, 29);
            this.txtMaHD.TabIndex = 2;
            // 
            // lblNhanVien
            // 
            this.lblNhanVien.Location = new System.Drawing.Point(21, 128);
            this.lblNhanVien.Name = "lblNhanVien";
            this.lblNhanVien.Size = new System.Drawing.Size(84, 29);
            this.lblNhanVien.TabIndex = 3;
            this.lblNhanVien.Text = "Nhân viên :";
            // 
            // cbNhanVien
            // 
            this.cbNhanVien.Location = new System.Drawing.Point(130, 128);
            this.cbNhanVien.Name = "cbNhanVien";
            this.cbNhanVien.Size = new System.Drawing.Size(263, 24);
            this.cbNhanVien.TabIndex = 4;
            this.cbNhanVien.SelectedIndexChanged += new System.EventHandler(this.cbNhanVien_SelectedIndexChanged);
            // 
            // lblKhachHang
            // 
            this.lblKhachHang.Location = new System.Drawing.Point(21, 184);
            this.lblKhachHang.Name = "lblKhachHang";
            this.lblKhachHang.Size = new System.Drawing.Size(84, 29);
            this.lblKhachHang.TabIndex = 5;
            this.lblKhachHang.Text = "Khách hàng :";
            // 
            // cbKhachHang
            // 
            this.cbKhachHang.Location = new System.Drawing.Point(130, 189);
            this.cbKhachHang.Name = "cbKhachHang";
            this.cbKhachHang.Size = new System.Drawing.Size(263, 24);
            this.cbKhachHang.TabIndex = 6;
            // 
            // lblNgayBan
            // 
            this.lblNgayBan.Location = new System.Drawing.Point(511, 83);
            this.lblNgayBan.Name = "lblNgayBan";
            this.lblNgayBan.Size = new System.Drawing.Size(84, 30);
            this.lblNgayBan.TabIndex = 7;
            this.lblNgayBan.Text = "Ngày bán :";
            // 
            // txtNgayBan
            // 
            this.txtNgayBan.Location = new System.Drawing.Point(635, 83);
            this.txtNgayBan.Multiline = true;
            this.txtNgayBan.Name = "txtNgayBan";
            this.txtNgayBan.Size = new System.Drawing.Size(263, 29);
            this.txtNgayBan.TabIndex = 8;
            // 
            // lblHinhThuc
            // 
            this.lblHinhThuc.Location = new System.Drawing.Point(511, 138);
            this.lblHinhThuc.Name = "lblHinhThuc";
            this.lblHinhThuc.Size = new System.Drawing.Size(84, 29);
            this.lblHinhThuc.TabIndex = 9;
            this.lblHinhThuc.Text = "Hình thức :";
            // 
            // txtHinhThuc
            // 
            this.txtHinhThuc.Location = new System.Drawing.Point(635, 135);
            this.txtHinhThuc.Multiline = true;
            this.txtHinhThuc.Name = "txtHinhThuc";
            this.txtHinhThuc.Size = new System.Drawing.Size(263, 29);
            this.txtHinhThuc.TabIndex = 10;
            // 
            // lblGhiChu
            // 
            this.lblGhiChu.Location = new System.Drawing.Point(511, 192);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(84, 29);
            this.lblGhiChu.TabIndex = 11;
            this.lblGhiChu.Text = "Ghi chú :";
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(635, 191);
            this.txtGhiChu.Multiline = true;
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(263, 29);
            this.txtGhiChu.TabIndex = 12;
            // 
            // lblTimKiem
            // 
            this.lblTimKiem.Location = new System.Drawing.Point(21, 242);
            this.lblTimKiem.Name = "lblTimKiem";
            this.lblTimKiem.Size = new System.Drawing.Size(84, 29);
            this.lblTimKiem.TabIndex = 13;
            this.lblTimKiem.Text = "Tìm kiếm :";
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.Location = new System.Drawing.Point(24, 269);
            this.txtTimKiem.Multiline = true;
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(582, 32);
            this.txtTimKiem.TabIndex = 14;
            // 
            // cbLoaiTim
            // 
            this.cbLoaiTim.Items.AddRange(new object[] {
            "Mã HD",
            "Ngày bán",
            "Hình thức"});
            this.cbLoaiTim.Location = new System.Drawing.Point(645, 269);
            this.cbLoaiTim.Name = "cbLoaiTim";
            this.cbLoaiTim.Size = new System.Drawing.Size(140, 24);
            this.cbLoaiTim.TabIndex = 15;
            // 
            // dgvHoaDon
            // 
            this.dgvHoaDon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHoaDon.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            this.dgvHoaDon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvHoaDon.ColumnHeadersHeight = 32;
            this.dgvHoaDon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaHD,
            this.colHoTenKH,
            this.colHoTenNV,
            this.colNgayBan,
            this.colHinhThucTT,
            this.colGhiChu,
            this.colTongTien});
            this.dgvHoaDon.Location = new System.Drawing.Point(24, 322);
            this.dgvHoaDon.Name = "dgvHoaDon";
            this.dgvHoaDon.RowHeadersVisible = false;
            this.dgvHoaDon.RowHeadersWidth = 51;
            this.dgvHoaDon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHoaDon.Size = new System.Drawing.Size(891, 286);
            this.dgvHoaDon.TabIndex = 17;
            // 
            // colMaHD
            // 
            this.colMaHD.HeaderText = "Mã HD";
            this.colMaHD.MinimumWidth = 6;
            this.colMaHD.Name = "colMaHD";
            // 
            // colHoTenKH
            // 
            this.colHoTenKH.HeaderText = "Khách hàng";
            this.colHoTenKH.MinimumWidth = 6;
            this.colHoTenKH.Name = "colHoTenKH";
            // 
            // colHoTenNV
            // 
            this.colHoTenNV.HeaderText = "Nhân viên";
            this.colHoTenNV.MinimumWidth = 6;
            this.colHoTenNV.Name = "colHoTenNV";
            // 
            // colNgayBan
            // 
            this.colNgayBan.HeaderText = "Ngày bán";
            this.colNgayBan.MinimumWidth = 6;
            this.colNgayBan.Name = "colNgayBan";
            // 
            // colHinhThucTT
            // 
            this.colHinhThucTT.HeaderText = "Hình thức TT";
            this.colHinhThucTT.MinimumWidth = 6;
            this.colHinhThucTT.Name = "colHinhThucTT";
            // 
            // colGhiChu
            // 
            this.colGhiChu.HeaderText = "Ghi chú";
            this.colGhiChu.MinimumWidth = 6;
            this.colGhiChu.Name = "colGhiChu";
            // 
            // colTongTien
            // 
            this.colTongTien.HeaderText = "Tổng tiền";
            this.colTongTien.MinimumWidth = 6;
            this.colTongTien.Name = "colTongTien";
            // 
            // UCHoaDon
            // 
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblMaHD);
            this.Controls.Add(this.txtMaHD);
            this.Controls.Add(this.lblNhanVien);
            this.Controls.Add(this.cbNhanVien);
            this.Controls.Add(this.lblKhachHang);
            this.Controls.Add(this.cbKhachHang);
            this.Controls.Add(this.lblNgayBan);
            this.Controls.Add(this.txtNgayBan);
            this.Controls.Add(this.lblHinhThuc);
            this.Controls.Add(this.txtHinhThuc);
            this.Controls.Add(this.lblGhiChu);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.lblTimKiem);
            this.Controls.Add(this.txtTimKiem);
            this.Controls.Add(this.cbLoaiTim);
            this.Controls.Add(this.dgvHoaDon);
            this.Name = "UCHoaDon";
            this.Size = new System.Drawing.Size(954, 700);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        // ========================= SUPPORT ===============================

        private void AddLabel(Label lbl, string text, int x, int y)
        {
            lbl.Text = text;
            lbl.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lbl.Location = new Point(x, y);
            lbl.AutoSize = true;
        }

        private void AddTextbox(TextBox txt, int x, int y, int w)
        {
            txt.Font = new Font("Segoe UI", 11F);
            txt.Location = new Point(x, y);
            txt.Size = new Size(w, 30);
        }

        private void FormatCombo(ComboBox cb, int x, int y, int w)
        {
            cb.Font = new Font("Segoe UI", 11F);
            cb.Location = new Point(x, y);
            cb.Size = new Size(w, 32);
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void FormatButton(Button btn, Color bg)
        {
            btn.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btn.BackColor = bg;
            btn.ForeColor = Color.White;
            btn.Size = new Size(110, 40);
            btn.FlatStyle = FlatStyle.Flat;
        }

        #endregion

        // DECLARE CONTROL
        private Label lblTitle, lblMaHD, lblNhanVien, lblKhachHang, lblNgayBan, lblHinhThuc,
                      lblGhiChu, lblTimKiem;

        private TextBox txtMaHD, txtNgayBan, txtHinhThuc, txtGhiChu, txtTimKiem, txtTongTien;

        private ComboBox cbNhanVien, cbKhachHang, cbLoaiTim;

        private DataGridView dgvHoaDon;
        private DataGridViewTextBoxColumn colMaHD, colHoTenKH, colHoTenNV,
                                          colNgayBan, colHinhThucTT, colGhiChu, colTongTien;
    }
}
