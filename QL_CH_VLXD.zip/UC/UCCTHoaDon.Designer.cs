﻿using Org.BouncyCastle.Asn1.Crmf;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyCuaHang_VLXD.UC
{ 
    partial class UCCTHoaDon
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Designer Code
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblMaHD = new System.Windows.Forms.Label();
            this.lblMaVL = new System.Windows.Forms.Label();
            this.lblTenVL = new System.Windows.Forms.Label();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.lblThanhTien = new System.Windows.Forms.Label();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.cbMaHD = new System.Windows.Forms.ComboBox();
            this.cbMaVL = new System.Windows.Forms.ComboBox();
            this.txtTenVL = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.dgvCTHD = new System.Windows.Forms.DataGridView();
            this.colMaHD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaVL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenVL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTHD)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lblTitle.Location = new System.Drawing.Point(315, 21);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(357, 50);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "CHI TIẾT HÓA ĐƠN";
            // 
            // lblMaHD
            // 
            this.lblMaHD.Location = new System.Drawing.Point(36, 90);
            this.lblMaHD.Name = "lblMaHD";
            this.lblMaHD.Size = new System.Drawing.Size(100, 23);
            this.lblMaHD.TabIndex = 1;
            this.lblMaHD.Text = "Mã HD :";
            // 
            // lblMaVL
            // 
            this.lblMaVL.Location = new System.Drawing.Point(36, 147);
            this.lblMaVL.Name = "lblMaVL";
            this.lblMaVL.Size = new System.Drawing.Size(100, 23);
            this.lblMaVL.TabIndex = 2;
            this.lblMaVL.Text = "Mã VL :";
            // 
            // lblTenVL
            // 
            this.lblTenVL.Location = new System.Drawing.Point(36, 214);
            this.lblTenVL.Name = "lblTenVL";
            this.lblTenVL.Size = new System.Drawing.Size(100, 23);
            this.lblTenVL.TabIndex = 3;
            this.lblTenVL.Text = "Tên VL :";
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.Location = new System.Drawing.Point(531, 91);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(100, 23);
            this.lblSoLuong.TabIndex = 4;
            this.lblSoLuong.Text = "Số lượng :";
            // 
            // lblDonGia
            // 
            this.lblDonGia.Location = new System.Drawing.Point(531, 143);
            this.lblDonGia.Name = "lblDonGia";
            this.lblDonGia.Size = new System.Drawing.Size(100, 23);
            this.lblDonGia.TabIndex = 5;
            this.lblDonGia.Text = "Đơn giá :";
            // 
            // lblThanhTien
            // 
            this.lblThanhTien.Location = new System.Drawing.Point(531, 193);
            this.lblThanhTien.Name = "lblThanhTien";
            this.lblThanhTien.Size = new System.Drawing.Size(100, 23);
            this.lblThanhTien.TabIndex = 6;
            this.lblThanhTien.Text = "Thành tiền :";
            // 
            // lblGhiChu
            // 
            this.lblGhiChu.Location = new System.Drawing.Point(531, 244);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(100, 23);
            this.lblGhiChu.TabIndex = 7;
            this.lblGhiChu.Text = "Ghi chú :";
            // 
            // cbMaHD
            // 
            this.cbMaHD.Location = new System.Drawing.Point(154, 87);
            this.cbMaHD.Name = "cbMaHD";
            this.cbMaHD.Size = new System.Drawing.Size(220, 24);
            this.cbMaHD.TabIndex = 8;
            // 
            // cbMaVL
            // 
            this.cbMaVL.Location = new System.Drawing.Point(154, 144);
            this.cbMaVL.Name = "cbMaVL";
            this.cbMaVL.Size = new System.Drawing.Size(220, 24);
            this.cbMaVL.TabIndex = 9;
            // 
            // txtTenVL
            // 
            this.txtTenVL.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtTenVL.Location = new System.Drawing.Point(154, 205);
            this.txtTenVL.Multiline = true;
            this.txtTenVL.Name = "txtTenVL";
            this.txtTenVL.ReadOnly = true;
            this.txtTenVL.Size = new System.Drawing.Size(220, 32);
            this.txtTenVL.TabIndex = 10;
            this.txtTenVL.TextChanged += new System.EventHandler(this.txtTenVL_TextChanged);
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(637, 91);
            this.txtSoLuong.Multiline = true;
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(220, 24);
            this.txtSoLuong.TabIndex = 11;
            // 
            // txtDonGia
            // 
            this.txtDonGia.Location = new System.Drawing.Point(637, 144);
            this.txtDonGia.Multiline = true;
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(220, 24);
            this.txtDonGia.TabIndex = 12;
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtThanhTien.Location = new System.Drawing.Point(637, 190);
            this.txtThanhTien.Multiline = true;
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.ReadOnly = true;
            this.txtThanhTien.Size = new System.Drawing.Size(220, 24);
            this.txtThanhTien.TabIndex = 13;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(637, 241);
            this.txtGhiChu.Multiline = true;
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(220, 24);
            this.txtGhiChu.TabIndex = 14;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnThem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnThem.Location = new System.Drawing.Point(69, 640);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(81, 33);
            this.btnThem.TabIndex = 15;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click_1);
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.Blue;
            this.btnSua.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSua.Location = new System.Drawing.Point(324, 640);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(81, 33);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click_1);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.BackColor = System.Drawing.Color.Purple;
            this.btnLamMoi.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLamMoi.Location = new System.Drawing.Point(576, 640);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(81, 33);
            this.btnLamMoi.TabIndex = 18;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = false;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click_1);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.Red;
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXoa.Location = new System.Drawing.Point(791, 640);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(81, 33);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click_1);
            // 
            // dgvCTHD
            // 
            this.dgvCTHD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            this.dgvCTHD.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvCTHD.ColumnHeadersHeight = 32;
            this.dgvCTHD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaHD,
            this.colMaVL,
            this.colTenVL,
            this.colSoLuong,
            this.colDonGia,
            this.colThanhTien,
            this.colGhiChu});
            this.dgvCTHD.Location = new System.Drawing.Point(22, 320);
            this.dgvCTHD.Name = "dgvCTHD";
            this.dgvCTHD.RowHeadersVisible = false;
            this.dgvCTHD.RowHeadersWidth = 51;
            this.dgvCTHD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCTHD.Size = new System.Drawing.Size(900, 300);
            this.dgvCTHD.TabIndex = 20;
            // 
            // colMaHD
            // 
            this.colMaHD.HeaderText = "Mã HĐ";
            this.colMaHD.MinimumWidth = 6;
            this.colMaHD.Name = "colMaHD";
            // 
            // colMaVL
            // 
            this.colMaVL.HeaderText = "Mã VL";
            this.colMaVL.MinimumWidth = 6;
            this.colMaVL.Name = "colMaVL";
            // 
            // colTenVL
            // 
            this.colTenVL.HeaderText = "Tên vật liệu";
            this.colTenVL.MinimumWidth = 6;
            this.colTenVL.Name = "colTenVL";
            // 
            // colSoLuong
            // 
            this.colSoLuong.HeaderText = "Số lượng";
            this.colSoLuong.MinimumWidth = 6;
            this.colSoLuong.Name = "colSoLuong";
            // 
            // colDonGia
            // 
            this.colDonGia.HeaderText = "Đơn giá";
            this.colDonGia.MinimumWidth = 6;
            this.colDonGia.Name = "colDonGia";
            // 
            // colThanhTien
            // 
            this.colThanhTien.HeaderText = "Thành tiền";
            this.colThanhTien.MinimumWidth = 6;
            this.colThanhTien.Name = "colThanhTien";
            // 
            // colGhiChu
            // 
            this.colGhiChu.HeaderText = "Ghi chú";
            this.colGhiChu.MinimumWidth = 6;
            this.colGhiChu.Name = "colGhiChu";
            // 
            // UCCTHoaDon
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblMaHD);
            this.Controls.Add(this.lblMaVL);
            this.Controls.Add(this.lblTenVL);
            this.Controls.Add(this.lblSoLuong);
            this.Controls.Add(this.lblDonGia);
            this.Controls.Add(this.lblThanhTien);
            this.Controls.Add(this.lblGhiChu);
            this.Controls.Add(this.cbMaHD);
            this.Controls.Add(this.cbMaVL);
            this.Controls.Add(this.txtTenVL);
            this.Controls.Add(this.txtSoLuong);
            this.Controls.Add(this.txtDonGia);
            this.Controls.Add(this.txtThanhTien);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.dgvCTHD);
            this.Name = "UCCTHoaDon";
            this.Size = new System.Drawing.Size(954, 700);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTHD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        // ========================= UTILITY FUNCTIONS =========================

        private void AddLabel(Label lbl, string text, int x, int y)
        {
            lbl.Text = text;
            lbl.Location = new Point(x, y);
            lbl.AutoSize = true;
            lbl.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        }

        private void AddTextbox(TextBox txt, int x, int y, int w)
        {
            txt.Font = new Font("Segoe UI", 11F);
            txt.Location = new Point(x, y);
            txt.Size = new Size(w, 30);
        }

        private void FormatCombo(ComboBox cb, int x, int y, int w)
        {
            cb.Font = new Font("Segoe UI", 11F);
            cb.Location = new Point(x, y);
            cb.Size = new Size(w, 32);
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void FormatButton(Button btn, Color bg)
        {
            btn.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btn.BackColor = bg;
            btn.ForeColor = Color.White;
            btn.Size = new Size(110, 40);
            btn.FlatStyle = FlatStyle.Flat;
        }

        #endregion

        // CONTROLS
        private Label lblTitle, lblMaHD, lblMaVL, lblTenVL, lblSoLuong, lblDonGia, lblThanhTien, lblGhiChu;
        private ComboBox cbMaHD, cbMaVL;
        private TextBox txtTenVL, txtSoLuong, txtDonGia, txtThanhTien, txtGhiChu;
        private Button btnThem, btnSua, btnLamMoi, btnXoa;
        private DataGridView dgvCTHD;
        private DataGridViewTextBoxColumn colMaHD, colMaVL, colTenVL, colSoLuong, colDonGia, colThanhTien, colGhiChu;
    }
}
