﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;

namespace QuanLyCuaHang_VLXD.UC
{
    public partial class UCHoaDon : UserControl
    {
        public UCHoaDon()
        {
            InitializeComponent();
            LoadComboData();
            LoadHoaDon();
        }

        // ===================================================
        //  KẾT NỐI DATABASE
        // ===================================================
        private MySqlConnection Connect()
        {
            return new MySqlConnection(
                "server=localhost;user=root;password=123456;port=3307;database=qlchvlxd;charset=utf8");
        }

        // ===================================================
        //  LOAD KHÁCH HÀNG + NHÂN VIÊN
        // ===================================================
        private void LoadComboData()
        {
            using (var conn = Connect())
            {
                conn.Open();

                // Khách hàng
                DataTable kh = new DataTable();
                new MySqlDataAdapter("SELECT MaKH, HoTen FROM khachhang", conn).Fill(kh);
                cbKhachHang.DataSource = kh;
                cbKhachHang.DisplayMember = "HoTen";
                cbKhachHang.ValueMember = "MaKH";
                cbKhachHang.SelectedIndex = -1;

                // Nhân viên
                DataTable nv = new DataTable();
                new MySqlDataAdapter("SELECT MaNV, HoTenNV FROM nhanvien", conn).Fill(nv);
                cbNhanVien.DataSource = nv;
                cbNhanVien.DisplayMember = "HoTenNV";
                cbNhanVien.ValueMember = "MaNV";
                cbNhanVien.SelectedIndex = -1;
            }
        }

        // ===================================================
        //  LOAD BẢNG HÓA ĐƠN
        // ===================================================
        private void LoadHoaDon()
        {
            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        SELECT hd.MaHD, kh.HoTen AS TenKH, nv.HoTenNV, 
                               hd.NgayBan, hd.HinhThucTT, hd.GhiChu, hd.TongTien
                        FROM hoadon hd
                        JOIN khachhang kh ON kh.MaKH = hd.MaKH
                        JOIN nhanvien nv ON nv.MaNV = hd.MaNV
                    ";

                    var da = new MySqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgvHoaDon.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi load hóa đơn: " + ex.Message);
            }
        }

        // ===================================================
        //  FORMAT TIỀN
        // ===================================================
        private string FormatMoney(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";

            var raw = s.Replace(".", "");
            if (long.TryParse(raw, out long value))
            {
                return value.ToString("N0", new CultureInfo("vi-VN"));
            }
            return s;
        }

        // ===================================================
        //  CHUẨN HÓA TÊN
        // ===================================================
        private string ChuanHoaTen(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "";

            string[] arr = name.Trim().ToLower().Split(' ');
            for (int i = 0; i < arr.Length; i++)
                arr[i] = char.ToUpper(arr[i][0]) + arr[i].Substring(1);
            return string.Join(" ", arr);
        }

        // ===================================================
        //  KIỂM TRA DỮ LIỆU
        // ===================================================
        private bool ValidateInput()
        {
            if (txtMaHD.Text.Trim() == "" ||
                cbKhachHang.SelectedIndex == -1 ||
                cbNhanVien.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Mã hóa đơn, Khách hàng, Nhân viên!");
                return false;
            }

            if (!DateTime.TryParseExact(txtNgayBan.Text, "yyyy-MM-dd",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
            {
                MessageBox.Show("Ngày bán phải theo định dạng yyyy-MM-dd !");
                return false;
            }

            return true;
        }

        // ===================================================
        //  TÍNH TỔNG TIỀN TỪ CHI TIẾT HÓA ĐƠN
        // ===================================================
        private long TinhTongTien(string maHD)
        {
            using (var conn = Connect())
            {
                conn.Open();

                var cmd = new MySqlCommand(
                    "SELECT SUM(ThanhTien) FROM cthoadon WHERE MaHD=@ma", conn);
                cmd.Parameters.AddWithValue("@ma", maHD);

                object result = cmd.ExecuteScalar();
                return result == DBNull.Value ? 0 : Convert.ToInt64(result);
            }
        }

        
        // ===================================================
        //  CLICK BẢNG → ĐỔ DỮ LIỆU
        // ===================================================
        private void dgvHoaDon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow r = dgvHoaDon.Rows[e.RowIndex];

            txtMaHD.Text = r.Cells["MaHD"].Value.ToString();
            cbKhachHang.Text = r.Cells["TenKH"].Value.ToString();
            cbNhanVien.Text = r.Cells["HoTenNV"].Value.ToString();
            txtNgayBan.Text = r.Cells["NgayBan"].Value.ToString();
            txtHinhThuc.Text = r.Cells["HinhThucTT"].Value.ToString();
            txtGhiChu.Text = r.Cells["GhiChu"].Value.ToString();
            txtTongTien.Text = FormatMoney(r.Cells["TongTien"].Value.ToString());
        }

        private void ClearInput()
        {
            txtMaHD.Clear();
            txtNgayBan.Clear();
            txtHinhThuc.Clear();
            txtGhiChu.Clear();
            txtTongTien.Clear();
            cbKhachHang.SelectedIndex = -1;
            cbNhanVien.SelectedIndex = -1;
        }

        private void cbNhanVien_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        
        private void btnThem_Click_1(object sender, EventArgs e)
        {
          
            
        }

       

        private void btnLuu_Click(object sender, EventArgs e)
        {}
       
       

        private void btnLamMoi_Click_1(object sender, EventArgs e)
        {
        }
        private void btnXoa_Click_1(object sender, EventArgs e)
        {
      
            
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            
        }
       
        private void button2_Click(object sender, EventArgs e)
        { 
        }
        private void button3_Click(object sender, EventArgs e)
        { 
            
        }

        // ===================================================
        //  THÊM HÓA ĐƠN
        // ===================================================
        private void button1_Click_1(object sender, EventArgs e)
        {
            
        
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    long tong = TinhTongTien(txtMaHD.Text);

                    string sql = @"
                        INSERT INTO hoadon (MaHD, MaKH, MaNV, NgayBan, HinhThucTT, GhiChu, TongTien)
                        VALUES (@MaHD, @MaKH, @MaNV, @NgayBan, @HTTT, @GC, @Tong)
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@MaHD", txtMaHD.Text);
                    cmd.Parameters.AddWithValue("@MaKH", cbKhachHang.SelectedValue);
                    cmd.Parameters.AddWithValue("@MaNV", cbNhanVien.SelectedValue);
                    cmd.Parameters.AddWithValue("@NgayBan", txtNgayBan.Text);
                    cmd.Parameters.AddWithValue("@HTTT", txtHinhThuc.Text);
                    cmd.Parameters.AddWithValue("@GC", txtGhiChu.Text);
                    cmd.Parameters.AddWithValue("@Tong", tong);

                    cmd.ExecuteNonQuery();

                    txtTongTien.Text = FormatMoney(tong.ToString());
                    MessageBox.Show("Thêm hóa đơn thành công!");
                    LoadHoaDon();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm hóa đơn: " + ex.Message);
            }
        }
        // ===================================================
        //  SỬA
        // ===================================================
        private void button2_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    long tong = TinhTongTien(txtMaHD.Text);

                    string sql = @"
                        UPDATE hoadon SET
                        MaKH=@MaKH, MaNV=@MaNV, NgayBan=@NgayBan,
                        HinhThucTT=@HTTT, GhiChu=@GC, TongTien=@Tong
                        WHERE MaHD=@MaHD
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@MaHD", txtMaHD.Text);
                    cmd.Parameters.AddWithValue("@MaKH", cbKhachHang.SelectedValue);
                    cmd.Parameters.AddWithValue("@MaNV", cbNhanVien.SelectedValue);
                    cmd.Parameters.AddWithValue("@NgayBan", txtNgayBan.Text);
                    cmd.Parameters.AddWithValue("@HTTT", txtHinhThuc.Text);
                    cmd.Parameters.AddWithValue("@GC", txtGhiChu.Text);
                    cmd.Parameters.AddWithValue("@Tong", tong);

                    cmd.ExecuteNonQuery();

                    txtTongTien.Text = FormatMoney(tong.ToString());
                    MessageBox.Show("Cập nhật hóa đơn thành công!");
                    LoadHoaDon();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa hóa đơn: " + ex.Message);
            }
        }
        // ===================================================
        //  LÀM MỚI
        // ===================================================
        private void button3_Click_1(object sender, EventArgs e)
        {

            ClearInput();
        }

        // ===================================================
        //  XÓA
        // ===================================================
        private void button4_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Bạn có chắc muốn xóa hóa đơn này?",
                "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.No) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();
                    var cmd = new MySqlCommand("DELETE FROM hoadon WHERE MaHD=@Ma", conn);
                    cmd.Parameters.AddWithValue("@Ma", txtMaHD.Text);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Xóa thành công!");
                    LoadHoaDon();
                    ClearInput();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa hóa đơn: " + ex.Message);
            }
        }
    }

}
