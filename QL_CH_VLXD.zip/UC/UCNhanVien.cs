﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace QuanLyCuaHang_VLXD.UC
{
    public partial class UCNhanVien : UserControl
    {
        public UCNhanVien()
        {
            InitializeComponent();
            LoadNhanVien();
            AddEvents();
        }

        // =============================
        //   KẾT NỐI DATABASE
        // =============================
        private MySqlConnection Connect()
        {
            return new MySqlConnection(
                "server=localhost;user=root;password=123456;port=3307;database=qlchvlxd;charset=utf8");
        }

        // =============================
        //   LOAD DATA
        // =============================
        private void LoadNhanVien()
        {
            try
            {
                using (var conn = Connect())
                {
                    conn.Open();
                    string sql = "SELECT * FROM nhanvien";
                    MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvNhanVien.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi load dữ liệu: " + ex.Message);
            }
        }

        // =============================
        //   FORMAT LƯƠNG
        // =============================
        private string FormatMoney(string input)
        {
            if (int.TryParse(input.Replace(".", ""), out int value))
                return value.ToString("N0", new CultureInfo("vi-VN"));

            return input;
        }

        // =============================
        //   KIỂM TRA DỮ LIỆU
        // =============================
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtMaNV.Text) ||
                string.IsNullOrWhiteSpace(txtHoTen.Text) ||
                string.IsNullOrWhiteSpace(txtSDT.Text))
            {
                MessageBox.Show("Không được để trống Mã NV, Họ tên, SĐT!");
                return false;
            }

            if (txtSDT.Text.Length != 10 || !long.TryParse(txtSDT.Text, out _))
            {
                MessageBox.Show("Số điện thoại phải đúng 10 số!");
                return false;
            }

            if (!DateTime.TryParseExact(
                txtNgaySinh.Text,
                "yyyy-MM-dd",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out _))
            {
                MessageBox.Show("Ngày sinh phải theo dạng yyyy-MM-dd!");
                return false;
            }

            if (!int.TryParse(txtLuong.Text.Replace(".", ""), out _))
            {
                MessageBox.Show("Lương không hợp lệ!");
                return false;
            }

            return true;
        }

        // =============================
        //   CLICK BẢNG → ĐỔ LÊN Ô
        // =============================
        private void dgvNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvNhanVien.Rows[e.RowIndex];

            txtMaNV.Text = row.Cells["MaNV"].Value?.ToString();
            txtHoTen.Text = row.Cells["HoTenNV"].Value?.ToString();
            txtSDT.Text = row.Cells["Sdt"].Value?.ToString();
            cbPhai.Text = row.Cells["Phai"].Value?.ToString();
            txtNgaySinh.Text = row.Cells["NgaySinh"].Value?.ToString();
            txtChucVu.Text = row.Cells["ChucVu"].Value?.ToString();
            txtDiaChi.Text = row.Cells["DiaChi"].Value?.ToString();
            txtLuong.Text = FormatMoney(row.Cells["Luong"].Value?.ToString());
            cbTinhTrang.Text = row.Cells["TinhTrang"].Value?.ToString();
        }
      
        private void ClearInput()
        {
            txtMaNV.Clear();
            txtHoTen.Clear();
            txtSDT.Clear();
            txtDiaChi.Clear();
            txtLuong.Clear();
            txtChucVu.Clear();
            txtNgaySinh.Clear();
            cbPhai.SelectedIndex = -1;
            cbTinhTrang.SelectedIndex = -1;
        }

        // =============================
        //  EVENT FORMAT LƯƠNG REALTIME
        // =============================
        private void AddEvents()
        {
            txtLuong.TextChanged += (s, e) =>
            {
                txtLuong.TextChanged -= null;
                txtLuong.Text = FormatMoney(txtLuong.Text);
                txtLuong.SelectionStart = txtLuong.Text.Length;
                txtLuong.TextChanged += (s2, e2) => { };
            };
        }

        private void lblDiaChi_Click(object sender, EventArgs e)
        {
        }

        private void lblNgaySinh_Click(object sender, EventArgs e)
        {
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {
        }


        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button6_Click(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
        }
        // =============================
        //   THÊM NHÂN VIÊN
        // =============================

        private void button7_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"INSERT INTO nhanvien 
                    (MaNV, HoTenNV, Sdt, Phai, NgaySinh, ChucVu, DiaChi, Luong, TinhTrang)
                    VALUES (@Ma, @Ten, @SDT, @Phai, @NgaySinh, @ChucVu, @DiaChi, @Luong, @TinhTrang)";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@Ma", txtMaNV.Text);
                    cmd.Parameters.AddWithValue("@Ten", txtHoTen.Text);
                    cmd.Parameters.AddWithValue("@SDT", txtSDT.Text);
                    cmd.Parameters.AddWithValue("@Phai", cbPhai.Text);
                    cmd.Parameters.AddWithValue("@NgaySinh", txtNgaySinh.Text);
                    cmd.Parameters.AddWithValue("@ChucVu", txtChucVu.Text);
                    cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text);
                    cmd.Parameters.AddWithValue("@Luong", txtLuong.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@TinhTrang", cbTinhTrang.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm nhân viên thành công!");
                    LoadNhanVien();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message);
            }
        }

        private void UCNhanVien_Load(object sender, EventArgs e)
        {

        }
        // =============================
        //   SỬA
        // =============================

        private void button10_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"UPDATE nhanvien SET
                    HoTenNV=@Ten, Sdt=@SDT, Phai=@Phai, NgaySinh=@NgaySinh, 
                    ChucVu=@ChucVu, DiaChi=@DiaChi, Luong=@Luong, TinhTrang=@TinhTrang
                    WHERE MaNV=@Ma";

                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@Ma", txtMaNV.Text);
                    cmd.Parameters.AddWithValue("@Ten", txtHoTen.Text);
                    cmd.Parameters.AddWithValue("@SDT", txtSDT.Text);
                    cmd.Parameters.AddWithValue("@Phai", cbPhai.Text);
                    cmd.Parameters.AddWithValue("@NgaySinh", txtNgaySinh.Text);
                    cmd.Parameters.AddWithValue("@ChucVu", txtChucVu.Text);
                    cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text);
                    cmd.Parameters.AddWithValue("@Luong", txtLuong.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@TinhTrang", cbTinhTrang.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cập nhật thành công!");
                    LoadNhanVien();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message);
            }
        }
        // =============================
        //   XÓA
        // =============================

        private void button9_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Bạn có chắc muốn xóa nhân viên này?",
                "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();
                    string sql = "DELETE FROM nhanvien WHERE MaNV=@Ma";
                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@Ma", txtMaNV.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công!");
                    LoadNhanVien();
                    ClearInput();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa: " + ex.Message);
            }
        }

        // =============================
        //   LÀM MỚI
        // =============================
        private void button11_Click(object sender, EventArgs e)
        {
            ClearInput();
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }
    }
}

