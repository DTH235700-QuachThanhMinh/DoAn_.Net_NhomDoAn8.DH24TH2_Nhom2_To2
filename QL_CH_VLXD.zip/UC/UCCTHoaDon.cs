﻿using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace QuanLyCuaHang_VLXD.UC
{
    public partial class UCCTHoaDon : UserControl
    {
        public UCCTHoaDon()
        {
            InitializeComponent();
            LoadComboHD();
            LoadComboVL();
            LoadCTHD();
            AddEvents();
        }

        // =================================================================
        // KẾT NỐI DB
        // =================================================================
        private MySqlConnection Connect()
        {
            return new MySqlConnection(
                "server=localhost;user=root;password=123456;port=3307;database=qlchvlxd;charset=utf8");
        }

        // =================================================================
        // FORMAT TIỀN >>> 1.000 – 25.000 – 2.500.000
        // =================================================================
        private string FormatMoney(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";

            s = s.Replace(".", "");

            if (long.TryParse(s, out long v))
                return v.ToString("N0", new CultureInfo("vi-VN"));

            return s;
        }

        // =================================================================
        // LOAD HÓA ĐƠN
        // =================================================================
        private void LoadComboHD()
        {
            using (var conn = Connect())
            {
                conn.Open();
                DataTable dt = new DataTable();
                new MySqlDataAdapter("SELECT MaHD FROM hoadon", conn).Fill(dt);

                cbMaHD.DataSource = dt;
                cbMaHD.DisplayMember = "MaHD";
                cbMaHD.ValueMember = "MaHD";
                cbMaHD.SelectedIndex = -1;
            }
        }

        // =================================================================
        // LOAD VẬT LIỆU
        // =================================================================
        private void LoadComboVL()
        {
            using (var conn = Connect())
            {
                conn.Open();

                string sql = "SELECT MaVL, TenVL, GiaBan FROM vatlieu";

                DataTable dt = new DataTable();
                new MySqlDataAdapter(sql, conn).Fill(dt);

                cbMaVL.DataSource = dt;
                cbMaVL.DisplayMember = "TenVL";
                cbMaVL.ValueMember = "MaVL";
                cbMaVL.SelectedIndex = -1;
            }
        }

        // =================================================================
        // LOAD CHI TIẾT HÓA ĐƠN
        // =================================================================
        private void LoadCTHD()
        {
            using (var conn = Connect())
            {
                conn.Open();

                string sql = @"
                    SELECT cthd.MaHD, vl.TenVL, cthd.SoLuong,
                           cthd.DonGia, cthd.ThanhTien, cthd.MaVL
                    FROM cthoadon cthd
                    JOIN vatlieu vl ON vl.MaVL = cthd.MaVL;
                ";

                DataTable dt = new DataTable();
                new MySqlDataAdapter(sql, conn);
                dgvCTHD.DataSource = dt;
            }
        }

        // =================================================================
        // EVENTS: AUTO FORMAT + TÍNH TIỀN
        // =================================================================
        private void AddEvents()
        {
            // Format tiền khi nhập đơn giá
            txtDonGia.TextChanged += (s, e) =>
            {
                if (!txtDonGia.Focused) return;

                string old = txtDonGia.Text;
                txtDonGia.Text = FormatMoney(old);
                txtDonGia.SelectionStart = txtDonGia.Text.Length;

                TinhThanhTien();
            };

            // Tính thành tiền khi nhập số lượng
            txtSoLuong.TextChanged += (s, e) => TinhThanhTien();

            // Khi chọn vật liệu → load giá bán
            cbMaVL.SelectedIndexChanged += (s, e) =>
            {
                if (cbMaVL.SelectedIndex < 0) return;

                DataRowView r = cbMaVL.SelectedItem as DataRowView;

                long gia = Convert.ToInt64(r["GiaBan"]);
                txtDonGia.Text = FormatMoney(gia.ToString());

                TinhThanhTien();
            };

            // Chỉ cho nhập số
            txtSoLuong.KeyPress += (s, e) =>
            {
                if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                    e.Handled = true;
            };
        }

        // =================================================================
        // TÍNH THÀNH TIỀN
        // =================================================================
        private void TinhThanhTien()
        {
            if (txtSoLuong.Text == "" || txtDonGia.Text == "")
            {
                txtThanhTien.Text = "0";
                return;
            }

            long sl = long.Parse(txtSoLuong.Text);
            long dg = long.Parse(txtDonGia.Text.Replace(".", ""));

            long tt = sl * dg;

            txtThanhTien.Text = tt.ToString("N0", new CultureInfo("vi-VN"));
        }

        // =================================================================
        // KIỂM TRA DỮ LIỆU
        // =================================================================
        private bool ValidateInput()
        {
            if (cbMaHD.SelectedIndex == -1 ||
                cbMaVL.SelectedIndex == -1 ||
                txtSoLuong.Text == "" ||
                txtDonGia.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu!");
                return false;
            }
            return true;
        }

        
        private void btnThem_Click(object sender, EventArgs e)
        {
            
        }

        // =================================================================
        // CLICK TABLE
        // =================================================================
        private void dgvCTHD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var r = dgvCTHD.Rows[e.RowIndex];

            cbMaHD.Text = r.Cells["MaHD"].Value.ToString();
            cbMaVL.Text = r.Cells["TenVL"].Value.ToString();
            txtSoLuong.Text = r.Cells["SoLuong"].Value.ToString();
            txtDonGia.Text = FormatMoney(r.Cells["DonGia"].Value.ToString());
            txtThanhTien.Text = FormatMoney(r.Cells["ThanhTien"].Value.ToString());
        }

        
        private void btnSua_Click(object sender, EventArgs e)
        {
            
        }

      
        private void btnXoa_Click(object sender, EventArgs e)
        {
        }

        

        private void ClearInput()
        {
            txtSoLuong.Clear();
            txtDonGia.Clear();
            txtThanhTien.Text = "0";
            cbMaHD.SelectedIndex = -1;
            cbMaVL.SelectedIndex = -1;
        }

        private void txtTenVL_TextChanged(object sender, EventArgs e)
        {

        }
        // =================================================================
        // THÊM
        // =================================================================
        private void btnThem_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        INSERT INTO cthoadon(MaHD, MaVL, SoLuong, DonGia, ThanhTien)
                        VALUES (@hd, @vl, @sl, @dg, @tt)
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@hd", cbMaHD.SelectedValue);
                    cmd.Parameters.AddWithValue("@vl", cbMaVL.SelectedValue);
                    cmd.Parameters.AddWithValue("@sl", txtSoLuong.Text);
                    cmd.Parameters.AddWithValue("@dg", txtDonGia.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@tt", txtThanhTien.Text.Replace(".", ""));
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Thêm thành công!");
                LoadCTHD();
                ClearInput();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message);
            }
        }
        // =================================================================
        // SỬA
        // =================================================================
        private void btnSua_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        UPDATE cthoadon SET
                            MaVL=@vl,
                            SoLuong=@sl,
                            DonGia=@dg,
                            ThanhTien=@tt
                        WHERE MaHD=@hd
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@hd", cbMaHD.SelectedValue);
                    cmd.Parameters.AddWithValue("@vl", cbMaVL.SelectedValue);
                    cmd.Parameters.AddWithValue("@sl", txtSoLuong.Text);
                    cmd.Parameters.AddWithValue("@dg", txtDonGia.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@tt", txtThanhTien.Text.Replace(".", ""));
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Sửa thành công!");
                LoadCTHD();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message);
            }
        }


        // =================================================================
        // LÀM MỚI
        // =================================================================
        private void btnLamMoi_Click_1(object sender, EventArgs e)
        {
         ClearInput();
        
        }
        // =================================================================
        // XÓA
        // =================================================================
        private void btnXoa_Click_1(object sender, EventArgs e)
        {

            if (MessageBox.Show("Bạn chắc chắn muốn xóa?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            using (var conn = Connect())
            {
                conn.Open();

                string sql = "DELETE FROM cthoadon WHERE MaHD=@hd AND MaVL=@vl";

                var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@hd", cbMaHD.SelectedValue);
                cmd.Parameters.AddWithValue("@vl", cbMaVL.SelectedValue);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Xóa thành công!");
            LoadCTHD();
            ClearInput();
        }
    }
}
