﻿using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace QuanLyCuaHang_VLXD.UC
{
    public partial class UCCTPhieuNhap : UserControl
    {
        public UCCTPhieuNhap()
        {
            InitializeComponent();
            LoadComboPN();
            LoadComboVL();
            LoadCTPN();
            AddEvents();
        }

        private MySqlConnection Connect()
        {
            return new MySqlConnection(
                "server=localhost;user=root;port=3307;password=123456;database=qlchvlxd;charset=utf8;");
        }

        private string FormatMoney(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";
            s = s.Replace(".", "");
            if (long.TryParse(s, out long v))
                return v.ToString("N0", new CultureInfo("vi-VN"));
            return s;
        }

        private void LoadComboPN()
        {
            using (var conn = Connect())
            {
                conn.Open();
                DataTable dt = new DataTable();
                new MySqlDataAdapter("SELECT MaPN FROM phieunhap", conn).Fill(dt);
                cbMaPN.DataSource = dt;
                cbMaPN.DisplayMember = "MaPN";
                cbMaPN.ValueMember = "MaPN";
                cbMaPN.SelectedIndex = -1;
            }
        }

        private void LoadComboVL()
        {
            using (var conn = Connect())
            {
                conn.Open();
                DataTable dt = new DataTable();
                new MySqlDataAdapter("SELECT MaVL, TenVL, GiaNhap FROM vatlieu", conn).Fill(dt);

                cbMaVL.DataSource = dt;
                cbMaVL.DisplayMember = "TenVL";
                cbMaVL.ValueMember = "MaVL";
                cbMaVL.SelectedIndex = -1;
            }
        }

        private void LoadCTPN()
        {
            using (var conn = Connect())
            {
                conn.Open();
                string sql = @"
                    SELECT ctpn.MaPN, vl.TenVL, ctpn.SoLuongNhap,
                           ctpn.DonGiaNhap, ctpn.ThanhTien, ctpn.MaVL
                    FROM ctphieunhap ctpn
                    JOIN vatlieu vl ON vl.MaVL = ctpn.MaVL;
                ";

                DataTable dt = new DataTable();
                new MySqlDataAdapter(sql, conn).Fill(dt);
                dgvCTPN.DataSource = dt;
            }
        }

        private void AddEvents()
        {
            txtDonGiaNhap.TextChanged += (s, e) =>
            {
                if (!txtDonGiaNhap.Focused) return;
                txtDonGiaNhap.Text = FormatMoney(txtDonGiaNhap.Text);
                txtDonGiaNhap.SelectionStart = txtDonGiaNhap.Text.Length;
                TinhThanhTien();
            };

            txtSoLuong.TextChanged += (s, e) => TinhThanhTien();

            cbMaVL.SelectedIndexChanged += (s, e) =>
            {
                if (cbMaVL.SelectedIndex < 0) return;

                DataRowView r = cbMaVL.SelectedItem as DataRowView;
                long gia = Convert.ToInt64(r["GiaNhap"]);
                txtDonGiaNhap.Text = FormatMoney(gia.ToString());
                TinhThanhTien();
            };

            txtSoLuong.KeyPress += (s, e) =>
            {
                if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                    e.Handled = true;
            };
        }

        private void TinhThanhTien()
        {
            if (txtSoLuong.Text == "" || txtDonGiaNhap.Text == "")
            {
                txtThanhTien.Text = "0";
                return;
            }

            long sl = long.Parse(txtSoLuong.Text);
            long dg = long.Parse(txtDonGiaNhap.Text.Replace(".", ""));
            long tt = sl * dg;

            txtThanhTien.Text = tt.ToString("N0", new CultureInfo("vi-VN"));
        }

        private bool ValidateInput()
        {
            if (cbMaPN.SelectedIndex == -1 ||
                cbMaVL.SelectedIndex == -1 ||
                txtSoLuong.Text == "" ||
                txtDonGiaNhap.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu!");
                return false;
            }
            return true;
        }

        private void UpdateTongTien(string maPN)
        {
            using (var conn = Connect())
            {
                conn.Open();
                string sql = @"UPDATE phieunhap
                               SET TongTien = (SELECT SUM(ThanhTien) 
                                               FROM ctphieunhap 
                                               WHERE MaPN = @pn)
                               WHERE MaPN = @pn";

                var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@pn", maPN);
                cmd.ExecuteNonQuery();
            }
        }

     

        private void dgvCTPN_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var r = dgvCTPN.Rows[e.RowIndex];

            cbMaPN.Text = r.Cells["MaPN"].Value.ToString();
            cbMaVL.Text = r.Cells["TenVL"].Value.ToString();
            txtSoLuong.Text = r.Cells["SoLuongNhap"].Value.ToString();
            txtDonGiaNhap.Text = FormatMoney(r.Cells["DonGiaNhap"].Value.ToString());
            txtThanhTien.Text = FormatMoney(r.Cells["ThanhTien"].Value.ToString());
        }

      
 

        private void btnLuu_Click(object sender, EventArgs e)
        {

        }

        private void btnSua_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        UPDATE ctphieunhap SET
                            MaVL=@vl,
                            SoLuongNhap=@sl,
                            DonGiaNhap=@dg,
                            ThanhTien=@tt
                        WHERE MaPN=@pn AND MaVL=@vl
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@pn", cbMaPN.SelectedValue);
                    cmd.Parameters.AddWithValue("@vl", cbMaVL.SelectedValue);
                    cmd.Parameters.AddWithValue("@sl", txtSoLuong.Text);
                    cmd.Parameters.AddWithValue("@dg", txtDonGiaNhap.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@tt", txtThanhTien.Text.Replace(".", ""));
                    cmd.ExecuteNonQuery();
                }

                UpdateTongTien(cbMaPN.SelectedValue.ToString());
                MessageBox.Show("Sửa thành công!");
                LoadCTPN();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message);
            }
        }

        private void btnLamMoi_Click_1(object sender, EventArgs e)
        {
            ClearInput();
        }

        private void ClearInput()
        {
            txtSoLuong.Clear();
            txtDonGiaNhap.Clear();
            txtThanhTien.Text = "0";
            cbMaPN.SelectedIndex = -1;
            cbMaVL.SelectedIndex = -1;
        }

        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn chắc chắn muốn xóa?", "Xác nhận",
               MessageBoxButtons.YesNo) == DialogResult.No) return;

            using (var conn = Connect())
            {
                conn.Open();
                string sql = "DELETE FROM ctphieunhap WHERE MaPN=@pn AND MaVL=@vl";

                var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@pn", cbMaPN.SelectedValue);
                cmd.Parameters.AddWithValue("@vl", cbMaVL.SelectedValue);
                cmd.ExecuteNonQuery();
            }

            UpdateTongTien(cbMaPN.SelectedValue.ToString());
            MessageBox.Show("Xóa thành công!");
            LoadCTPN();
            ClearInput();
        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        INSERT INTO ctphieunhap(MaPN, MaVL, SoLuongNhap, DonGiaNhap, ThanhTien)
                        VALUES (@pn, @vl, @sl, @dg, @tt)
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@pn", cbMaPN.SelectedValue);
                    cmd.Parameters.AddWithValue("@vl", cbMaVL.SelectedValue);
                    cmd.Parameters.AddWithValue("@sl", txtSoLuong.Text);
                    cmd.Parameters.AddWithValue("@dg", txtDonGiaNhap.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@tt", txtThanhTien.Text.Replace(".", ""));
                    cmd.ExecuteNonQuery();
                }

                UpdateTongTien(cbMaPN.SelectedValue.ToString());
                MessageBox.Show("Thêm thành công!");
                LoadCTPN();
                ClearInput();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message);
            }
        }
    }
}
