﻿using System.Drawing;
using System.Windows.Forms;

namespace QuanLyCuaHang_VLXD.UC 
{
    partial class UCPhieuNhap
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Designer Code
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblMaPN = new System.Windows.Forms.Label();
            this.lblNgayNhap = new System.Windows.Forms.Label();
            this.lblNCC = new System.Windows.Forms.Label();
            this.lblNV = new System.Windows.Forms.Label();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.lblTimKiem = new System.Windows.Forms.Label();
            this.txtMaPN = new System.Windows.Forms.TextBox();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.dtNgayNhap = new System.Windows.Forms.DateTimePicker();
            this.cbNCC = new System.Windows.Forms.ComboBox();
            this.cbNhanVien = new System.Windows.Forms.ComboBox();
            this.cbLoaiTim = new System.Windows.Forms.ComboBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnTim = new System.Windows.Forms.Button();
            this.dgvPhieuNhap = new System.Windows.Forms.DataGridView();
            this.colMaPN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTongTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuNhap)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lblTitle.Location = new System.Drawing.Point(230, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(417, 50);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ PHIẾU NHẬP";
            // 
            // lblMaPN
            // 
            this.lblMaPN.Location = new System.Drawing.Point(27, 75);
            this.lblMaPN.Name = "lblMaPN";
            this.lblMaPN.Size = new System.Drawing.Size(100, 23);
            this.lblMaPN.TabIndex = 1;
            this.lblMaPN.Text = "Mã PN :";
            // 
            // lblNgayNhap
            // 
            this.lblNgayNhap.Location = new System.Drawing.Point(496, 75);
            this.lblNgayNhap.Name = "lblNgayNhap";
            this.lblNgayNhap.Size = new System.Drawing.Size(100, 23);
            this.lblNgayNhap.TabIndex = 2;
            this.lblNgayNhap.Text = "Ngày nhập :";
            // 
            // lblNCC
            // 
            this.lblNCC.Location = new System.Drawing.Point(27, 174);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(100, 23);
            this.lblNCC.TabIndex = 3;
            this.lblNCC.Text = "NCC ;";
            // 
            // lblNV
            // 
            this.lblNV.Location = new System.Drawing.Point(496, 123);
            this.lblNV.Name = "lblNV";
            this.lblNV.Size = new System.Drawing.Size(100, 23);
            this.lblNV.TabIndex = 4;
            this.lblNV.Text = "Nhân viên :";
            // 
            // lblTongTien
            // 
            this.lblTongTien.Location = new System.Drawing.Point(496, 174);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(100, 23);
            this.lblTongTien.TabIndex = 5;
            this.lblTongTien.Text = "Tổng tiền :";
            // 
            // lblGhiChu
            // 
            this.lblGhiChu.Location = new System.Drawing.Point(27, 127);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(100, 23);
            this.lblGhiChu.TabIndex = 6;
            this.lblGhiChu.Text = "Ghi chú :";
            // 
            // lblTimKiem
            // 
            this.lblTimKiem.Location = new System.Drawing.Point(27, 216);
            this.lblTimKiem.Name = "lblTimKiem";
            this.lblTimKiem.Size = new System.Drawing.Size(100, 23);
            this.lblTimKiem.TabIndex = 7;
            this.lblTimKiem.Text = "Tìm kiếm :";
            // 
            // txtMaPN
            // 
            this.txtMaPN.Location = new System.Drawing.Point(133, 67);
            this.txtMaPN.Multiline = true;
            this.txtMaPN.Name = "txtMaPN";
            this.txtMaPN.Size = new System.Drawing.Size(250, 32);
            this.txtMaPN.TabIndex = 8;
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(640, 165);
            this.txtTongTien.Multiline = true;
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(250, 32);
            this.txtTongTien.TabIndex = 9;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(133, 120);
            this.txtGhiChu.Multiline = true;
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(250, 32);
            this.txtGhiChu.TabIndex = 10;
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.Location = new System.Drawing.Point(30, 253);
            this.txtTimKiem.Multiline = true;
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(584, 33);
            this.txtTimKiem.TabIndex = 11;
            // 
            // dtNgayNhap
            // 
            this.dtNgayNhap.CustomFormat = "yyyy-MM-dd";
            this.dtNgayNhap.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.dtNgayNhap.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayNhap.Location = new System.Drawing.Point(640, 67);
            this.dtNgayNhap.Name = "dtNgayNhap";
            this.dtNgayNhap.Size = new System.Drawing.Size(250, 32);
            this.dtNgayNhap.TabIndex = 12;
            // 
            // cbNCC
            // 
            this.cbNCC.Location = new System.Drawing.Point(133, 174);
            this.cbNCC.Name = "cbNCC";
            this.cbNCC.Size = new System.Drawing.Size(250, 24);
            this.cbNCC.TabIndex = 13;
            // 
            // cbNhanVien
            // 
            this.cbNhanVien.Location = new System.Drawing.Point(640, 120);
            this.cbNhanVien.Name = "cbNhanVien";
            this.cbNhanVien.Size = new System.Drawing.Size(250, 24);
            this.cbNhanVien.TabIndex = 14;
            // 
            // cbLoaiTim
            // 
            this.cbLoaiTim.Items.AddRange(new object[] {
            "Mã PN",
            "Nhà cung cấp",
            "NCC",
            "Ngày nhập"});
            this.cbLoaiTim.Location = new System.Drawing.Point(653, 262);
            this.cbLoaiTim.Name = "cbLoaiTim";
            this.cbLoaiTim.Size = new System.Drawing.Size(132, 24);
            this.cbLoaiTim.TabIndex = 15;
            this.cbLoaiTim.Text = "Mã PN";
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnThem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnThem.Location = new System.Drawing.Point(91, 635);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 34);
            this.btnThem.TabIndex = 16;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click_1);
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.Blue;
            this.btnSua.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSua.Location = new System.Drawing.Point(322, 635);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 34);
            this.btnSua.TabIndex = 18;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click_1);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.BackColor = System.Drawing.Color.Purple;
            this.btnLamMoi.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLamMoi.Location = new System.Drawing.Point(572, 635);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(75, 34);
            this.btnLamMoi.TabIndex = 19;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = false;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click_1);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.Red;
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXoa.Location = new System.Drawing.Point(778, 635);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 34);
            this.btnXoa.TabIndex = 20;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click_1);
            // 
            // btnTim
            // 
            this.btnTim.BackColor = System.Drawing.Color.Gray;
            this.btnTim.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTim.Location = new System.Drawing.Point(820, 254);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size = new System.Drawing.Size(110, 32);
            this.btnTim.TabIndex = 21;
            this.btnTim.Text = "Tìm";
            this.btnTim.UseVisualStyleBackColor = false;
            // 
            // dgvPhieuNhap
            // 
            this.dgvPhieuNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            this.dgvPhieuNhap.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvPhieuNhap.ColumnHeadersHeight = 32;
            this.dgvPhieuNhap.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaPN,
            this.colNgayNhap,
            this.colTenNCC,
            this.colTenNV,
            this.colTongTien,
            this.colGhiChu});
            this.dgvPhieuNhap.Location = new System.Drawing.Point(30, 304);
            this.dgvPhieuNhap.Name = "dgvPhieuNhap";
            this.dgvPhieuNhap.RowHeadersVisible = false;
            this.dgvPhieuNhap.RowHeadersWidth = 51;
            this.dgvPhieuNhap.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhieuNhap.Size = new System.Drawing.Size(900, 300);
            this.dgvPhieuNhap.TabIndex = 22;
            // 
            // colMaPN
            // 
            this.colMaPN.HeaderText = "Mã PN";
            this.colMaPN.MinimumWidth = 6;
            this.colMaPN.Name = "colMaPN";
            // 
            // colNgayNhap
            // 
            this.colNgayNhap.HeaderText = "Ngày nhập";
            this.colNgayNhap.MinimumWidth = 6;
            this.colNgayNhap.Name = "colNgayNhap";
            // 
            // colTenNCC
            // 
            this.colTenNCC.HeaderText = "Nhà cung cấp";
            this.colTenNCC.MinimumWidth = 6;
            this.colTenNCC.Name = "colTenNCC";
            // 
            // colTenNV
            // 
            this.colTenNV.HeaderText = "Nhân viên";
            this.colTenNV.MinimumWidth = 6;
            this.colTenNV.Name = "colTenNV";
            // 
            // colTongTien
            // 
            this.colTongTien.HeaderText = "Tổng tiền";
            this.colTongTien.MinimumWidth = 6;
            this.colTongTien.Name = "colTongTien";
            // 
            // colGhiChu
            // 
            this.colGhiChu.HeaderText = "Ghi chú";
            this.colGhiChu.MinimumWidth = 6;
            this.colGhiChu.Name = "colGhiChu";
            // 
            // UCPhieuNhap
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblMaPN);
            this.Controls.Add(this.lblNgayNhap);
            this.Controls.Add(this.lblNCC);
            this.Controls.Add(this.lblNV);
            this.Controls.Add(this.lblTongTien);
            this.Controls.Add(this.lblGhiChu);
            this.Controls.Add(this.lblTimKiem);
            this.Controls.Add(this.txtMaPN);
            this.Controls.Add(this.txtTongTien);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.txtTimKiem);
            this.Controls.Add(this.dtNgayNhap);
            this.Controls.Add(this.cbNCC);
            this.Controls.Add(this.cbNhanVien);
            this.Controls.Add(this.cbLoaiTim);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnTim);
            this.Controls.Add(this.dgvPhieuNhap);
            this.Name = "UCPhieuNhap";
            this.Size = new System.Drawing.Size(954, 700);
            this.Load += new System.EventHandler(this.UCPhieuNhap_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuNhap)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        // ========================= UTILS =========================

        private void AddLabel(Label lbl, string text, int x, int y)
        {
            lbl.Text = text;
            lbl.Location = new Point(x, y);
            lbl.AutoSize = true;
            lbl.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        }

        private void AddTextbox(TextBox txt, int x, int y, int w)
        {
            txt.Font = new Font("Segoe UI", 11F);
            txt.Location = new Point(x, y);
            txt.Size = new Size(w, 30);
        }

        private void FormatCombo(ComboBox cb, int x, int y, int w)
        {
            cb.Font = new Font("Segoe UI", 11F);
            cb.Location = new Point(x, y);
            cb.Size = new Size(w, 32);
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void FormatButton(Button btn, Color bg)
        {
            btn.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btn.BackColor = bg;
            btn.ForeColor = Color.White;
            btn.Size = new Size(110, 40);
            btn.FlatStyle = FlatStyle.Flat;
        }

        #endregion

        // ========== CONTROLS ==============
        private Label lblTitle, lblMaPN, lblNgayNhap, lblNCC, lblNV, lblTongTien, lblGhiChu, lblTimKiem;
        private TextBox txtMaPN, txtTongTien, txtGhiChu, txtTimKiem;
        private DateTimePicker dtNgayNhap;
        private ComboBox cbNCC, cbNhanVien, cbLoaiTim;
        private Button btnThem, btnSua, btnLamMoi, btnXoa, btnTim;
        private DataGridView dgvPhieuNhap;
        private DataGridViewTextBoxColumn colMaPN, colNgayNhap, colTenNCC, colTenNV, colTongTien, colGhiChu;
    }
}
