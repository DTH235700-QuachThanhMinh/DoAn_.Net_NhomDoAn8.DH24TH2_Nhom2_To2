﻿using Org.BouncyCastle.Asn1.Crmf;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyCuaHang_VLXD.UC
{
    partial class UCCTPhieuNhap
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Designer Code
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblMaPN = new System.Windows.Forms.Label();
            this.lblMaVL = new System.Windows.Forms.Label();
            this.lblTenVL = new System.Windows.Forms.Label();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.lblThanhTien = new System.Windows.Forms.Label();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.cbMaPN = new System.Windows.Forms.ComboBox();
            this.cbMaVL = new System.Windows.Forms.ComboBox();
            this.txtTenVL = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtDonGiaNhap = new System.Windows.Forms.TextBox();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.dgvCTPN = new System.Windows.Forms.DataGridView();
            this.colMaPN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaVL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenVL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTPN)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lblTitle.Location = new System.Drawing.Point(250, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(407, 50);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "CHI TIẾT PHIẾU NHẬP";
            // 
            // lblMaPN
            // 
            this.lblMaPN.Location = new System.Drawing.Point(18, 72);
            this.lblMaPN.Name = "lblMaPN";
            this.lblMaPN.Size = new System.Drawing.Size(100, 23);
            this.lblMaPN.TabIndex = 1;
            this.lblMaPN.Text = "Mã PN :";
            // 
            // lblMaVL
            // 
            this.lblMaVL.Location = new System.Drawing.Point(18, 117);
            this.lblMaVL.Name = "lblMaVL";
            this.lblMaVL.Size = new System.Drawing.Size(100, 23);
            this.lblMaVL.TabIndex = 2;
            this.lblMaVL.Text = "Mã VL :";
            // 
            // lblTenVL
            // 
            this.lblTenVL.Location = new System.Drawing.Point(18, 159);
            this.lblTenVL.Name = "lblTenVL";
            this.lblTenVL.Size = new System.Drawing.Size(100, 23);
            this.lblTenVL.TabIndex = 3;
            this.lblTenVL.Text = "Tên VL :";
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.Location = new System.Drawing.Point(526, 72);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(100, 23);
            this.lblSoLuong.TabIndex = 4;
            this.lblSoLuong.Text = "Số  lượng :";
            // 
            // lblDonGia
            // 
            this.lblDonGia.Location = new System.Drawing.Point(526, 117);
            this.lblDonGia.Name = "lblDonGia";
            this.lblDonGia.Size = new System.Drawing.Size(100, 23);
            this.lblDonGia.TabIndex = 5;
            this.lblDonGia.Text = "Đơn giá :";
            // 
            // lblThanhTien
            // 
            this.lblThanhTien.Location = new System.Drawing.Point(526, 174);
            this.lblThanhTien.Name = "lblThanhTien";
            this.lblThanhTien.Size = new System.Drawing.Size(100, 23);
            this.lblThanhTien.TabIndex = 6;
            this.lblThanhTien.Text = "Thành tiền :";
            // 
            // lblGhiChu
            // 
            this.lblGhiChu.Location = new System.Drawing.Point(18, 211);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(100, 23);
            this.lblGhiChu.TabIndex = 7;
            this.lblGhiChu.Text = "Ghi chú :";
            // 
            // cbMaPN
            // 
            this.cbMaPN.Location = new System.Drawing.Point(124, 71);
            this.cbMaPN.Name = "cbMaPN";
            this.cbMaPN.Size = new System.Drawing.Size(242, 24);
            this.cbMaPN.TabIndex = 8;
            // 
            // cbMaVL
            // 
            this.cbMaVL.Location = new System.Drawing.Point(124, 116);
            this.cbMaVL.Name = "cbMaVL";
            this.cbMaVL.Size = new System.Drawing.Size(242, 24);
            this.cbMaVL.TabIndex = 9;
            // 
            // txtTenVL
            // 
            this.txtTenVL.Location = new System.Drawing.Point(124, 160);
            this.txtTenVL.Name = "txtTenVL";
            this.txtTenVL.ReadOnly = true;
            this.txtTenVL.Size = new System.Drawing.Size(250, 22);
            this.txtTenVL.TabIndex = 10;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(632, 69);
            this.txtSoLuong.Multiline = true;
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(250, 31);
            this.txtSoLuong.TabIndex = 11;
            // 
            // txtDonGiaNhap
            // 
            this.txtDonGiaNhap.Location = new System.Drawing.Point(632, 118);
            this.txtDonGiaNhap.Multiline = true;
            this.txtDonGiaNhap.Name = "txtDonGiaNhap";
            this.txtDonGiaNhap.Size = new System.Drawing.Size(250, 31);
            this.txtDonGiaNhap.TabIndex = 12;
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.Location = new System.Drawing.Point(632, 175);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.ReadOnly = true;
            this.txtThanhTien.Size = new System.Drawing.Size(250, 22);
            this.txtThanhTien.TabIndex = 13;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(124, 208);
            this.txtGhiChu.Multiline = true;
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(250, 31);
            this.txtGhiChu.TabIndex = 14;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnThem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnThem.Location = new System.Drawing.Point(84, 610);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 34);
            this.btnThem.TabIndex = 15;
            this.btnThem.Text = "Thêm ";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click_1);
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.Blue;
            this.btnSua.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSua.Location = new System.Drawing.Point(330, 610);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 34);
            this.btnSua.TabIndex = 17;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click_1);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.BackColor = System.Drawing.Color.Purple;
            this.btnLamMoi.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLamMoi.Location = new System.Drawing.Point(571, 610);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(75, 34);
            this.btnLamMoi.TabIndex = 18;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = false;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click_1);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.Red;
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXoa.Location = new System.Drawing.Point(784, 610);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 34);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click_1);
            // 
            // dgvCTPN
            // 
            this.dgvCTPN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            this.dgvCTPN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCTPN.ColumnHeadersHeight = 29;
            this.dgvCTPN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaPN,
            this.colMaVL,
            this.colTenVL,
            this.colSoLuong,
            this.colDonGia,
            this.colThanhTien,
            this.colGhiChu});
            this.dgvCTPN.Location = new System.Drawing.Point(21, 278);
            this.dgvCTPN.Name = "dgvCTPN";
            this.dgvCTPN.RowHeadersVisible = false;
            this.dgvCTPN.RowHeadersWidth = 51;
            this.dgvCTPN.Size = new System.Drawing.Size(900, 300);
            this.dgvCTPN.TabIndex = 20;
            // 
            // colMaPN
            // 
            this.colMaPN.MinimumWidth = 6;
            this.colMaPN.Name = "colMaPN";
            // 
            // colMaVL
            // 
            this.colMaVL.MinimumWidth = 6;
            this.colMaVL.Name = "colMaVL";
            // 
            // colTenVL
            // 
            this.colTenVL.MinimumWidth = 6;
            this.colTenVL.Name = "colTenVL";
            // 
            // colSoLuong
            // 
            this.colSoLuong.MinimumWidth = 6;
            this.colSoLuong.Name = "colSoLuong";
            // 
            // colDonGia
            // 
            this.colDonGia.MinimumWidth = 6;
            this.colDonGia.Name = "colDonGia";
            // 
            // colThanhTien
            // 
            this.colThanhTien.MinimumWidth = 6;
            this.colThanhTien.Name = "colThanhTien";
            // 
            // colGhiChu
            // 
            this.colGhiChu.MinimumWidth = 6;
            this.colGhiChu.Name = "colGhiChu";
            // 
            // UCCTPhieuNhap
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblMaPN);
            this.Controls.Add(this.lblMaVL);
            this.Controls.Add(this.lblTenVL);
            this.Controls.Add(this.lblSoLuong);
            this.Controls.Add(this.lblDonGia);
            this.Controls.Add(this.lblThanhTien);
            this.Controls.Add(this.lblGhiChu);
            this.Controls.Add(this.cbMaPN);
            this.Controls.Add(this.cbMaVL);
            this.Controls.Add(this.txtTenVL);
            this.Controls.Add(this.txtSoLuong);
            this.Controls.Add(this.txtDonGiaNhap);
            this.Controls.Add(this.txtThanhTien);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.dgvCTPN);
            this.Name = "UCCTPhieuNhap";
            this.Size = new System.Drawing.Size(954, 700);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTPN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        // ================== CÁC HÀM TIỆN ÍCH (PHẢI CÓ) ==================

        private void AddLabel(Label lbl, string text, int x, int y)
        {
            lbl.Text = text;
            lbl.Location = new Point(x, y);
            lbl.AutoSize = true;
            lbl.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        }

        private void AddTextbox(TextBox txt, int x, int y, int w)
        {
            txt.Font = new Font("Segoe UI", 11F);
            txt.Location = new Point(x, y);
            txt.Size = new Size(w, 30);
        }

        private void FormatCombo(ComboBox cb, int x, int y, int w)
        {
            cb.Font = new Font("Segoe UI", 11F);
            cb.Location = new Point(x, y);
            cb.Size = new Size(w, 32);
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void FormatButton(Button btn, string text, int x, int y, Color color)
        {
            btn.Text = text;
            btn.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btn.Location = new Point(x, y);
            btn.Size = new Size(110, 40);
            btn.BackColor = color;
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
        }

        // ===== Controls =====
        private Label lblTitle, lblMaPN, lblMaVL, lblTenVL, lblSoLuong, lblDonGia, lblThanhTien, lblGhiChu;
        private ComboBox cbMaPN, cbMaVL;
        private TextBox txtTenVL, txtSoLuong, txtDonGiaNhap, txtThanhTien, txtGhiChu;
        private Button btnThem, btnSua, btnLamMoi, btnXoa;
        private DataGridView dgvCTPN;
        private DataGridViewTextBoxColumn colMaPN, colMaVL, colTenVL, colSoLuong, colDonGia, colThanhTien, colGhiChu;
    }
}
