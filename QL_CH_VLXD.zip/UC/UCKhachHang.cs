﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace QuanLyCuaHang_VLXD.UC
{
    public partial class UCKhachHang : UserControl
    {
        public UCKhachHang()
        {
            InitializeComponent();
            LoadKH();
            AddEvents();
        }

        private MySqlConnection Connect()
        {
            return new MySqlConnection("server=localhost;user=root;port=3307;password=123456;database=qlchvlxd;charset=utf8");
        }

        private void LoadKH()
        {
            try
            {
                using (var conn = Connect())
                {
                    conn.Open();
                    string sql = "SELECT * FROM khachhang";
                    MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvKhachHang.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi load khách hàng: " + ex.Message);
            }
        }

        private bool ValidateInput()
        {
            if (txtMaKH.Text == "" || txtTenKH.Text == "" || txtSDT.Text == "")
            {
                MessageBox.Show("Không được để trống Mã KH, Tên KH, SĐT!");
                return false;
            }

            if (txtSDT.Text.Length != 10 || !long.TryParse(txtSDT.Text, out _))
            {
                MessageBox.Show("Số điện thoại phải 10 số!");
                return false;
            }

            return true;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
           
        }

        private void dgvKhachHang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var r = dgvKhachHang.Rows[e.RowIndex];

            txtMaKH.Text = r.Cells["MaKH"].Value?.ToString();
            txtTenKH.Text = r.Cells["HoTen"].Value?.ToString();
            cbGioiTinh.Text = r.Cells["GioiTinh"].Value?.ToString();
            txtSDT.Text = r.Cells["SDT"].Value?.ToString();
            txtEmail.Text = r.Cells["Email"].Value?.ToString();
            txtDiaChi.Text = r.Cells["DiaChi"].Value?.ToString();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
          
        }

        private void AddEvents()
        {
            dgvKhachHang.CellClick += dgvKhachHang_CellClick;
            btnThem.Click += btnThem_Click;
            btnSua.Click += btnSua_Click;
            btnXoa.Click += btnXoa_Click;
            btnLamMoi.Click += btnLamMoi_Click;
        }

        private void txtMaKH_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();
                    string sql = @"INSERT INTO khachhang (MaKH, HoTen, GioiTinh, SDT, Email, DiaChi)
                                   VALUES (@Ma, @Ten, @GT, @SDT, @Email, @DiaChi)";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@Ma", txtMaKH.Text);
                    cmd.Parameters.AddWithValue("@Ten", txtTenKH.Text);
                    cmd.Parameters.AddWithValue("@GT", cbGioiTinh.Text);
                    cmd.Parameters.AddWithValue("@SDT", txtSDT.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm khách hàng thành công!");
                    LoadKH();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm KH: " + ex.Message);
            }
        }

        private void btnSua_Click_1(object sender, EventArgs e)
        {
            if(!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();
                    string sql = @"UPDATE khachhang SET
                                HoTen=@Ten, GioiTinh=@GT, SDT=@SDT,
                                Email=@Email, DiaChi=@DiaChi
                                WHERE MaKH=@Ma";

                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@Ma", txtMaKH.Text);
                    cmd.Parameters.AddWithValue("@Ten", txtTenKH.Text);
                    cmd.Parameters.AddWithValue("@GT", cbGioiTinh.Text);
                    cmd.Parameters.AddWithValue("@SDT", txtSDT.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cập nhật thành công!");
                    LoadKH();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message);
            }
        }

        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Xóa khách hàng này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();
                    var cmd = new MySqlCommand("DELETE FROM khachhang WHERE MaKH=@Ma", conn);
                    cmd.Parameters.AddWithValue("@Ma", txtMaKH.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Đã xóa!");
                    LoadKH();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa: " + ex.Message);
            }
        }

        private void btnLamMoi_Click_1(object sender, EventArgs e)
        {
            txtMaKH.Clear();
            txtTenKH.Clear();
            txtSDT.Clear();
            txtEmail.Clear();
            txtDiaChi.Clear();
            cbGioiTinh.SelectedIndex = -1;
        }
    }
}
