﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Globalization;


namespace QuanLyCuaHang_VLXD.UC
{
    public partial class UCPhieuNhap : UserControl
    {
        public UCPhieuNhap()
        {
            InitializeComponent();
            LoadComboNCC();
            LoadComboNV();
            LoadPhieuNhap();
            AddEvents();
        }

        // ============================================================
        // KẾT NỐI
        // ============================================================
        private MySqlConnection Connect()
        {
            return new MySqlConnection(
                "server=localhost;user=root;password=123456;port=3307;database=qlchvlxd;charset=utf8");
        }

        // ============================================================
        // LOAD COMBO NHÀ CUNG CẤP
        // ============================================================
        private void LoadComboNCC()
        {
            using (var conn = Connect())
            {
                conn.Open();

                DataTable dt = new DataTable();
                new MySqlDataAdapter("SELECT MaNCC, TenNCC FROM nhacungcap", conn).Fill(dt);

                cbNCC.DataSource = dt;
                cbNCC.DisplayMember = "TenNCC";
                cbNCC.ValueMember = "MaNCC";
                cbNCC.SelectedIndex = -1;
            }
        }

        // ============================================================
        // LOAD COMBO NHÂN VIÊN
        // ============================================================
        private void LoadComboNV()
        {
            using (var conn = Connect())
            {
                conn.Open();

                DataTable dt = new DataTable();
                new MySqlDataAdapter("SELECT MaNV, HoTenNV FROM nhanvien", conn).Fill(dt);

                cbNhanVien.DataSource = dt;
                cbNhanVien.DisplayMember = "HoTenNV";
                cbNhanVien.ValueMember = "MaNV";
                cbNhanVien.SelectedIndex = -1;
            }
        }

        // ============================================================
        // LOAD PHIẾU NHẬP
        // ============================================================
        private void LoadPhieuNhap()
        {
            using (var conn = Connect())
            {
                conn.Open();

                string sql = @"
                    SELECT pn.MaPN, pn.NgayNhap, ncc.TenNCC, nv.HoTenNV,
                           pn.TongTien, pn.GhiChu
                    FROM phieunhap pn
                    JOIN nhacungcap ncc ON ncc.MaNCC = pn.MaNCC
                    JOIN nhanvien nv ON nv.MaNV = pn.MaNV
                ";

                DataTable dt = new DataTable();
                new MySqlDataAdapter(sql, conn).Fill(dt);

                dgvPhieuNhap.DataSource = dt;
            }
        }

        // ============================================================
        // FORMAT TIỀN 1.000 – 12.000 – 100.000
        // ============================================================
        private string FormatMoney(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";
            s = s.Replace(".", "");

            if (long.TryParse(s, out long v))
                return v.ToString("N0", new CultureInfo("vi-VN"));

            return s;
        }

        private void AddEvents()
        {
            txtTongTien.TextChanged += (s, e) =>
            {
                if (txtTongTien.Focused)
                {
                    txtTongTien.Text = FormatMoney(txtTongTien.Text);
                    txtTongTien.SelectionStart = txtTongTien.Text.Length;
                }
            };
        }

        // ============================================================
        // KIỂM TRA
        // ============================================================
        private bool ValidateInput()
        {
            if (txtMaPN.Text == "" ||
                cbNCC.SelectedIndex == -1 ||
                cbNhanVien.SelectedIndex == -1 ||
                txtTongTien.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return false;
            }

            return true;
        }

        // ============================================================
        // CLICK DGV -> ĐỔ LÊN Ô
        // ============================================================
        private void dgvPhieuNhap_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var r = dgvPhieuNhap.Rows[e.RowIndex];

            txtMaPN.Text = r.Cells["MaPN"].Value.ToString();
            dtNgayNhap.Text = r.Cells["NgayNhap"].Value.ToString();
            cbNCC.Text = r.Cells["TenNCC"].Value.ToString();
            cbNhanVien.Text = r.Cells["HoTenNV"].Value.ToString();
            txtTongTien.Text = FormatMoney(r.Cells["TongTien"].Value.ToString());
            txtGhiChu.Text = r.Cells["GhiChu"].Value.ToString();
        }

     
        private void ClearInput()
        {
            txtMaPN.Clear();
            txtTongTien.Clear();
            txtGhiChu.Clear();
            cbNCC.SelectedIndex = -1;
            cbNhanVien.SelectedIndex = -1;
            dtNgayNhap.Value = DateTime.Now;
        }

        // ============================================================
        // THÊM PHIẾU NHẬP
        // ============================================================
        private void UCPhieuNhap_Load(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        INSERT INTO phieunhap(MaPN, NgayNhap, MaNCC, MaNV, TongTien, GhiChu)
                        VALUES (@ma, @ngay, @ncc, @nv, @tien, @gc)
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaPN.Text);
                    cmd.Parameters.AddWithValue("@ngay", dtNgayNhap.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@ncc", cbNCC.SelectedValue);
                    cmd.Parameters.AddWithValue("@nv", cbNhanVien.SelectedValue);
                    cmd.Parameters.AddWithValue("@tien", txtTongTien.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@gc", txtGhiChu.Text);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Thêm phiếu nhập thành công!");
                LoadPhieuNhap();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message);
            }
        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {

            if (!ValidateInput()) return;
            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    // Lấy tổng tiền (nếu nhập sẵn)
                    long tongTien = 0;
                    long.TryParse(txtTongTien.Text.Replace(".", ""), out tongTien);

                    string sql = @"
                INSERT INTO phieunhap
                (MaPN, NgayNhap, MaNCC, MaNV, TongTien, GhiChu)
                VALUES
                (@MaPN, @NgayNhap, @MaNCC, @MaNV, @TongTien, @GhiChu)
            ";

                    var cmd = new MySqlCommand(sql, conn);

                    cmd.Parameters.AddWithValue("@MaPN", txtMaPN.Text);
                    cmd.Parameters.AddWithValue("@NgayNhap", dtNgayNhap.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@MaNCC", cbNCC.SelectedValue);
                    cmd.Parameters.AddWithValue("@MaNV", cbNhanVien.SelectedValue);
                    cmd.Parameters.AddWithValue("@TongTien", tongTien);
                    cmd.Parameters.AddWithValue("@GhiChu", txtGhiChu.Text);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Thêm phiếu nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadPhieuNhap();
                ClearInput();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm phiếu nhập: " + ex.Message);
            }
        }
        // ============================================================
        // SỬA
        // ============================================================
        private void btnSua_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        UPDATE phieunhap SET
                            NgayNhap=@ngay,
                            MaNCC=@ncc,
                            MaNV=@nv,
                            TongTien=@tien,
                            GhiChu=@gc
                        WHERE MaPN=@ma
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaPN.Text);
                    cmd.Parameters.AddWithValue("@ngay", dtNgayNhap.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@ncc", cbNCC.SelectedValue);
                    cmd.Parameters.AddWithValue("@nv", cbNhanVien.SelectedValue);
                    cmd.Parameters.AddWithValue("@tien", txtTongTien.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@gc", txtGhiChu.Text);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Cập nhật thành công!");
                LoadPhieuNhap();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message);
            }
        }
        // ============================================================
        // LÀM MỚI
        // ============================================================
       
        private void btnLamMoi_Click_1(object sender, EventArgs e)
        {
            ClearInput();
        }
        // ============================================================
        // XÓA
        // ============================================================
       
        private void btnXoa_Click_1(object sender, EventArgs e)
        {
           
            if (MessageBox.Show("Bạn chắc chắn muốn xóa?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            using (var conn = Connect())
            {
                conn.Open();

                var cmd = new MySqlCommand("DELETE FROM phieunhap WHERE MaPN=@ma", conn);
                cmd.Parameters.AddWithValue("@ma", txtMaPN.Text);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Xóa thành công!");
            LoadPhieuNhap();
            ClearInput();
        }
    }
    
}

