﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace QuanLyCuaHang_VLXD.UC
{
    public partial class UCNhaCungCap : UserControl
    {
        public UCNhaCungCap()
        {
            InitializeComponent();
            LoadNCC();
            AddEvents();
        }

        // ===========================================
        // KẾT NỐI
        // ===========================================
        private MySqlConnection Connect()
        {
            return new MySqlConnection(
                "server=localhost;user=root;password=123456;port=3307;database=qlchvlxd;charset=utf8");
        }

        // ===========================================
        // TỰ ĐỘNG VIẾT HOA CHỮ CÁI ĐẦU
        // ===========================================
        private string Capitalize(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return "";

            return string.Join(" ", text
                .Trim()
                .ToLower()
                .Split(' ')
                .Where(w => w.Trim() != "")
                .Select(w => char.ToUpper(w[0]) + w.Substring(1))
            );
        }

        private void AddEvents()
        {
            txtTenNCC.Leave += (s, e) => txtTenNCC.Text = Capitalize(txtTenNCC.Text);
            txtDiaChi.Leave += (s, e) => txtDiaChi.Text = Capitalize(txtDiaChi.Text);
            txtGhiChu.Leave += (s, e) => txtGhiChu.Text = Capitalize(txtGhiChu.Text);

            // Chỉ cho nhập số vào SDT
            txtSDT.KeyPress += (s, e) =>
            {
                if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                    e.Handled = true;
            };
        }

        // ===========================================
        // KIỂM TRA SỐ ĐIỆN THOẠI
        // ===========================================
        private bool ValidatePhone()
        {
            if (txtSDT.Text.Length != 10)
            {
                MessageBox.Show("Số điện thoại phải đúng 10 số!");
                return false;
            }
            return true;
        }

        // ===========================================
        // KIỂM TRA DỮ LIỆU
        // ===========================================
        private bool ValidateInput()
        {
            if (txtMaNCC.Text == "" ||
                txtTenNCC.Text == "" ||
                txtSDT.Text == "" ||
                txtDiaChi.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return false;
            }

            if (!ValidatePhone()) return false;

            return true;
        }

        // ===========================================
        // LOAD NHÀ CUNG CẤP
        // ===========================================
        private void LoadNCC()
        {
            using (var conn = Connect())
            {
                conn.Open();

                string sql = "SELECT * FROM nhacungcap";

                DataTable dt = new DataTable();
                new MySqlDataAdapter(sql, conn).Fill(dt);

                dgvNCC.DataSource = dt;
            }
        }

        // ===========================================
        // CLICK BẢNG → ĐỔ DỮ LIỆU LÊN Ô
        // ===========================================
        private void dgvNCC_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var r = dgvNCC.Rows[e.RowIndex];

            txtMaNCC.Text = r.Cells["MaNCC"].Value.ToString();
            txtTenNCC.Text = r.Cells["TenNCC"].Value.ToString();
            txtSDT.Text = r.Cells["SDT"].Value.ToString();
            txtDiaChi.Text = r.Cells["DiaChi"].Value.ToString();
            txtGhiChu.Text = r.Cells["GhiChu"].Value.ToString();
        }

     
        private void btnSua_Click(object sender, EventArgs e)
        {
            
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            
        }

        
        private void btnLamMoi_Click(object sender, EventArgs e)
        {
          
        }

        private void ClearInput()
        {
            txtMaNCC.Clear();
            txtTenNCC.Clear();
            txtSDT.Clear();
            txtDiaChi.Clear();
            txtGhiChu.Clear();
        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {

        }
        // ===========================================
        // THÊM NHÀ CUNG CẤP
        // ===========================================

        private void button1_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        INSERT INTO nhacungcap(MaNCC, TenNCC, SDT, DiaChi, GhiChu)
                        VALUES (@ma, @ten, @sdt, @dc, @gc)
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaNCC.Text);
                    cmd.Parameters.AddWithValue("@ten", txtTenNCC.Text);
                    cmd.Parameters.AddWithValue("@sdt", txtSDT.Text);
                    cmd.Parameters.AddWithValue("@dc", txtDiaChi.Text);
                    cmd.Parameters.AddWithValue("@gc", txtGhiChu.Text);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Thêm nhà cung cấp thành công!");
                LoadNCC();
                ClearInput();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClearInput();
        }
        // ===========================================
        // SỬA
        // ===========================================
        private void button3_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        UPDATE nhacungcap SET
                            TenNCC=@ten,
                            SDT=@sdt,
                            DiaChi=@dc,
                            GhiChu=@gc
                        WHERE MaNCC=@ma
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaNCC.Text);
                    cmd.Parameters.AddWithValue("@ten", txtTenNCC.Text);
                    cmd.Parameters.AddWithValue("@sdt", txtSDT.Text);
                    cmd.Parameters.AddWithValue("@dc", txtDiaChi.Text);
                    cmd.Parameters.AddWithValue("@gc", txtGhiChu.Text);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Cập nhật thành công!");
                LoadNCC();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message);
            }
        }

        // ===========================================
        // XÓA
        // ===========================================
        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn chắc chắn muốn xóa?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            using (var conn = Connect())
            {
                conn.Open();

                string sql = "DELETE FROM nhacungcap WHERE MaNCC=@ma";

                var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", txtMaNCC.Text);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Xóa thành công!");
            LoadNCC();
            ClearInput();
        }
    }
}
