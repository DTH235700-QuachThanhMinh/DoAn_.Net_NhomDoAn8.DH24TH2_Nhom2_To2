﻿using System.Drawing;
using System.Windows.Forms;

namespace QuanLyCuaHang_VLXD.UC
{
    partial class UCVatLieu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Designer Code
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblMaVL = new System.Windows.Forms.Label();
            this.lblTenVL = new System.Windows.Forms.Label();
            this.lblDonViTinh = new System.Windows.Forms.Label();
            this.lblGiaNhap = new System.Windows.Forms.Label();
            this.lblGiaBan = new System.Windows.Forms.Label();
            this.lblTonKho = new System.Windows.Forms.Label();
            this.lblNCC = new System.Windows.Forms.Label();
            this.lblTimKiem = new System.Windows.Forms.Label();
            this.txtMaVL = new System.Windows.Forms.TextBox();
            this.txtTenVL = new System.Windows.Forms.TextBox();
            this.txtDonViTinh = new System.Windows.Forms.TextBox();
            this.txtGiaNhap = new System.Windows.Forms.TextBox();
            this.txtGiaBan = new System.Windows.Forms.TextBox();
            this.txtTonKho = new System.Windows.Forms.TextBox();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.cbNCC = new System.Windows.Forms.ComboBox();
            this.cbLoaiTim = new System.Windows.Forms.ComboBox();
            this.uCVatLieuBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnTim = new System.Windows.Forms.Button();
            this.dgvVatLieu = new System.Windows.Forms.DataGridView();
            this.colMaVL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenVL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonViTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGiaNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGiaBan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTonKho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.databaseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.uCVatLieuBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVatLieu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lblTitle.Location = new System.Drawing.Point(250, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(352, 50);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ VẬT LIỆU";
            // 
            // lblMaVL
            // 
            this.lblMaVL.Location = new System.Drawing.Point(22, 78);
            this.lblMaVL.Name = "lblMaVL";
            this.lblMaVL.Size = new System.Drawing.Size(100, 23);
            this.lblMaVL.TabIndex = 1;
            this.lblMaVL.Text = "Mã VL :";
            // 
            // lblTenVL
            // 
            this.lblTenVL.Location = new System.Drawing.Point(22, 123);
            this.lblTenVL.Name = "lblTenVL";
            this.lblTenVL.Size = new System.Drawing.Size(100, 23);
            this.lblTenVL.TabIndex = 2;
            this.lblTenVL.Text = "Tên VL :";
            // 
            // lblDonViTinh
            // 
            this.lblDonViTinh.Location = new System.Drawing.Point(22, 160);
            this.lblDonViTinh.Name = "lblDonViTinh";
            this.lblDonViTinh.Size = new System.Drawing.Size(100, 23);
            this.lblDonViTinh.TabIndex = 3;
            this.lblDonViTinh.Text = "Đơn vị tính :";
            // 
            // lblGiaNhap
            // 
            this.lblGiaNhap.Location = new System.Drawing.Point(22, 205);
            this.lblGiaNhap.Name = "lblGiaNhap";
            this.lblGiaNhap.Size = new System.Drawing.Size(100, 23);
            this.lblGiaNhap.TabIndex = 4;
            this.lblGiaNhap.Text = "Giá nhập :";
            // 
            // lblGiaBan
            // 
            this.lblGiaBan.Location = new System.Drawing.Point(472, 89);
            this.lblGiaBan.Name = "lblGiaBan";
            this.lblGiaBan.Size = new System.Drawing.Size(100, 23);
            this.lblGiaBan.TabIndex = 5;
            this.lblGiaBan.Text = "Giá bán :";
            // 
            // lblTonKho
            // 
            this.lblTonKho.Location = new System.Drawing.Point(472, 138);
            this.lblTonKho.Name = "lblTonKho";
            this.lblTonKho.Size = new System.Drawing.Size(100, 23);
            this.lblTonKho.TabIndex = 6;
            this.lblTonKho.Text = "Tồn kho :";
            // 
            // lblNCC
            // 
            this.lblNCC.Location = new System.Drawing.Point(472, 184);
            this.lblNCC.Name = "lblNCC";
            this.lblNCC.Size = new System.Drawing.Size(100, 23);
            this.lblNCC.TabIndex = 7;
            this.lblNCC.Text = "NCC :";
            // 
            // lblTimKiem
            // 
            this.lblTimKiem.Location = new System.Drawing.Point(21, 247);
            this.lblTimKiem.Name = "lblTimKiem";
            this.lblTimKiem.Size = new System.Drawing.Size(100, 23);
            this.lblTimKiem.TabIndex = 8;
            this.lblTimKiem.Text = "Tìm kiếm :";
            // 
            // txtMaVL
            // 
            this.txtMaVL.Location = new System.Drawing.Point(136, 71);
            this.txtMaVL.Multiline = true;
            this.txtMaVL.Name = "txtMaVL";
            this.txtMaVL.Size = new System.Drawing.Size(199, 30);
            this.txtMaVL.TabIndex = 9;
            this.txtMaVL.TextChanged += new System.EventHandler(this.txtMaVL_TextChanged);
            // 
            // txtTenVL
            // 
            this.txtTenVL.Location = new System.Drawing.Point(136, 116);
            this.txtTenVL.Multiline = true;
            this.txtTenVL.Name = "txtTenVL";
            this.txtTenVL.Size = new System.Drawing.Size(199, 30);
            this.txtTenVL.TabIndex = 10;
            this.txtTenVL.TextChanged += new System.EventHandler(this.txtTenVL_TextChanged);
            // 
            // txtDonViTinh
            // 
            this.txtDonViTinh.Location = new System.Drawing.Point(136, 160);
            this.txtDonViTinh.Multiline = true;
            this.txtDonViTinh.Name = "txtDonViTinh";
            this.txtDonViTinh.Size = new System.Drawing.Size(199, 30);
            this.txtDonViTinh.TabIndex = 11;
            this.txtDonViTinh.TextChanged += new System.EventHandler(this.txtDonViTinh_TextChanged);
            // 
            // txtGiaNhap
            // 
            this.txtGiaNhap.Location = new System.Drawing.Point(136, 206);
            this.txtGiaNhap.Multiline = true;
            this.txtGiaNhap.Name = "txtGiaNhap";
            this.txtGiaNhap.Size = new System.Drawing.Size(199, 30);
            this.txtGiaNhap.TabIndex = 12;
            this.txtGiaNhap.TextChanged += new System.EventHandler(this.txtGiaNhap_TextChanged);
            // 
            // txtGiaBan
            // 
            this.txtGiaBan.Location = new System.Drawing.Point(585, 78);
            this.txtGiaBan.Multiline = true;
            this.txtGiaBan.Name = "txtGiaBan";
            this.txtGiaBan.Size = new System.Drawing.Size(199, 30);
            this.txtGiaBan.TabIndex = 13;
            this.txtGiaBan.TextChanged += new System.EventHandler(this.txtGiaBan_TextChanged);
            // 
            // txtTonKho
            // 
            this.txtTonKho.Location = new System.Drawing.Point(585, 135);
            this.txtTonKho.Multiline = true;
            this.txtTonKho.Name = "txtTonKho";
            this.txtTonKho.Size = new System.Drawing.Size(199, 30);
            this.txtTonKho.TabIndex = 14;
            this.txtTonKho.TextChanged += new System.EventHandler(this.txtTonKho_TextChanged);
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.Location = new System.Drawing.Point(25, 282);
            this.txtTimKiem.Multiline = true;
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(590, 33);
            this.txtTimKiem.TabIndex = 15;
            // 
            // cbNCC
            // 
            this.cbNCC.Location = new System.Drawing.Point(585, 184);
            this.cbNCC.Name = "cbNCC";
            this.cbNCC.Size = new System.Drawing.Size(199, 24);
            this.cbNCC.TabIndex = 16;
            this.cbNCC.SelectedIndexChanged += new System.EventHandler(this.cbNCC_SelectedIndexChanged);
            // 
            // cbLoaiTim
            // 
            this.cbLoaiTim.Items.AddRange(new object[] {
            "Mã VL",
            "Tên VL",
            "Đơn vị tính",
            "NCC"});
            this.cbLoaiTim.Location = new System.Drawing.Point(647, 287);
            this.cbLoaiTim.Name = "cbLoaiTim";
            this.cbLoaiTim.Size = new System.Drawing.Size(151, 24);
            this.cbLoaiTim.TabIndex = 17;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnThem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnThem.Location = new System.Drawing.Point(71, 640);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 39);
            this.btnThem.TabIndex = 20;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click_1);
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.Blue;
            this.btnSua.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSua.Location = new System.Drawing.Point(319, 640);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 39);
            this.btnSua.TabIndex = 22;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click_1);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.BackColor = System.Drawing.Color.Purple;
            this.btnLamMoi.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLamMoi.Location = new System.Drawing.Point(562, 640);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(75, 39);
            this.btnLamMoi.TabIndex = 23;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = false;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click_1);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.Red;
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXoa.Location = new System.Drawing.Point(808, 640);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 39);
            this.btnXoa.TabIndex = 24;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click_1);
            // 
            // btnTim
            // 
            this.btnTim.BackColor = System.Drawing.Color.Gray;
            this.btnTim.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTim.Location = new System.Drawing.Point(829, 282);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size = new System.Drawing.Size(99, 33);
            this.btnTim.TabIndex = 18;
            this.btnTim.Text = "Tìm";
            this.btnTim.UseVisualStyleBackColor = false;
            // 
            // dgvVatLieu
            // 
            this.dgvVatLieu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            this.dgvVatLieu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvVatLieu.ColumnHeadersHeight = 32;
            this.dgvVatLieu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaVL,
            this.colTenVL,
            this.colDonViTinh,
            this.colGiaNhap,
            this.colGiaBan,
            this.colTonKho,
            this.colTenNCC});
            this.dgvVatLieu.Location = new System.Drawing.Point(25, 340);
            this.dgvVatLieu.Name = "dgvVatLieu";
            this.dgvVatLieu.RowHeadersVisible = false;
            this.dgvVatLieu.RowHeadersWidth = 51;
            this.dgvVatLieu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvVatLieu.Size = new System.Drawing.Size(903, 280);
            this.dgvVatLieu.TabIndex = 19;
            // 
            // colMaVL
            // 
            this.colMaVL.HeaderText = "Mã VL";
            this.colMaVL.MinimumWidth = 6;
            this.colMaVL.Name = "colMaVL";
            // 
            // colTenVL
            // 
            this.colTenVL.HeaderText = "Tên vật liệu";
            this.colTenVL.MinimumWidth = 6;
            this.colTenVL.Name = "colTenVL";
            // 
            // colDonViTinh
            // 
            this.colDonViTinh.HeaderText = "Đơn vị tính";
            this.colDonViTinh.MinimumWidth = 6;
            this.colDonViTinh.Name = "colDonViTinh";
            // 
            // colGiaNhap
            // 
            this.colGiaNhap.HeaderText = "Giá nhập";
            this.colGiaNhap.MinimumWidth = 6;
            this.colGiaNhap.Name = "colGiaNhap";
            // 
            // colGiaBan
            // 
            this.colGiaBan.HeaderText = "Giá bán";
            this.colGiaBan.MinimumWidth = 6;
            this.colGiaBan.Name = "colGiaBan";
            // 
            // colTonKho
            // 
            this.colTonKho.HeaderText = "Tồn kho";
            this.colTonKho.MinimumWidth = 6;
            this.colTonKho.Name = "colTonKho";
            // 
            // colTenNCC
            // 
            this.colTenNCC.HeaderText = "Nhà cung cấp";
            this.colTenNCC.MinimumWidth = 6;
            this.colTenNCC.Name = "colTenNCC";
            // 
            // UCVatLieu
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblMaVL);
            this.Controls.Add(this.lblTenVL);
            this.Controls.Add(this.lblDonViTinh);
            this.Controls.Add(this.lblGiaNhap);
            this.Controls.Add(this.lblGiaBan);
            this.Controls.Add(this.lblTonKho);
            this.Controls.Add(this.lblNCC);
            this.Controls.Add(this.lblTimKiem);
            this.Controls.Add(this.txtMaVL);
            this.Controls.Add(this.txtTenVL);
            this.Controls.Add(this.txtDonViTinh);
            this.Controls.Add(this.txtGiaNhap);
            this.Controls.Add(this.txtGiaBan);
            this.Controls.Add(this.txtTonKho);
            this.Controls.Add(this.txtTimKiem);
            this.Controls.Add(this.cbNCC);
            this.Controls.Add(this.cbLoaiTim);
            this.Controls.Add(this.btnTim);
            this.Controls.Add(this.dgvVatLieu);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnXoa);
            this.Name = "UCVatLieu";
            this.Size = new System.Drawing.Size(954, 700);
            this.Load += new System.EventHandler(this.UCVatLieu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.uCVatLieuBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVatLieu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        // ========================= UTILS =========================

        private void AddLabel(Label lbl, string text, int x, int y)
        {
            lbl.Text = text;
            lbl.Location = new Point(x, y);
            lbl.AutoSize = true;
            lbl.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        }

        private void AddTextbox(TextBox txt, int x, int y, int w)
        {
            txt.Font = new Font("Segoe UI", 11F);
            txt.Location = new Point(x, y);
            txt.Size = new Size(w, 30);
        }

        private void FormatCombo(ComboBox cb, int x, int y, int w)
        {
            cb.Font = new Font("Segoe UI", 11F);
            cb.Location = new Point(x, y);
            cb.Size = new Size(w, 32);
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void FormatButton(Button btn, Color bg)
        {
            btn.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btn.BackColor = bg;
            btn.ForeColor = Color.White;
            btn.Size = new Size(110, 40);
            btn.FlatStyle = FlatStyle.Flat;
        }

        #endregion

        // ========== DECLARE CONTROLS ==============
        private Label lblTitle, lblMaVL, lblTenVL, lblDonViTinh, lblGiaNhap, lblGiaBan,
                      lblTonKho, lblNCC, lblTimKiem;

        private TextBox txtMaVL, txtTenVL, txtDonViTinh, txtGiaNhap,
                        txtGiaBan, txtTonKho, txtTimKiem;

        private ComboBox cbNCC, cbLoaiTim;

        private Button btnThem, btnSua, btnLamMoi, btnXoa, btnTim;

        private DataGridView dgvVatLieu;
        private DataGridViewTextBoxColumn
            colMaVL, colTenVL, colDonViTinh, colGiaNhap, colGiaBan, colTonKho, colTenNCC;
        private BindingSource uCVatLieuBindingSource;
        private BindingSource databaseBindingSource;
    }
}
