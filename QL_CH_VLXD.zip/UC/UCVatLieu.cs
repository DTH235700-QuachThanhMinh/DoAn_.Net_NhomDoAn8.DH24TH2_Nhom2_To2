﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
using System.Globalization;


namespace QuanLyCuaHang_VLXD.UC
{
    public partial class UCVatLieu : UserControl
    {
        public UCVatLieu()
        {
            InitializeComponent();
            LoadComboNCC();
            LoadVatLieu();
            AddEvents();
        }

        // ======================================
        //  KẾT NỐI DATABASE
        // ======================================
        private MySqlConnection Connect()
        {
            return new MySqlConnection(
                "server=localhost;user=root;password=123456;port=3307;database=qlchvlxd;charset=utf8");
        }

        // ======================================
        //  LOAD COMBO NHÀ CUNG CẤP
        // ======================================
        private void LoadComboNCC()
        {
            using (var conn = Connect())
            {
                conn.Open();

                DataTable dt = new DataTable();
                new MySqlDataAdapter("SELECT MaNCC, TenNCC FROM nhacungcap", conn).Fill(dt);

                cbNCC.DataSource = dt;
                cbNCC.DisplayMember = "TenNCC";
                cbNCC.ValueMember = "MaNCC";
                cbNCC.SelectedIndex = -1;
            }
        }

        // ======================================
        //  LOAD BẢNG VẬT LIỆU
        // ======================================
        private void LoadVatLieu()
        {
            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        SELECT vl.MaVL, vl.TenVL, vl.DonViTinh,
                               vl.GiaNhap, vl.GiaBan, vl.TonKho,
                               ncc.TenNCC
                        FROM vatlieu vl
                        JOIN nhacungcap ncc ON ncc.MaNCC = vl.MaNCC
                    ";

                    var da = new MySqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dgvVatLieu.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi load vật liệu: " + ex.Message);
            }
        }

        // ======================================
        //  FORMAT TIỀN (5.000 – 12.000 – 980.000)
        // ======================================
        private string FormatMoney(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";

            s = s.Replace(".", "");

            if (long.TryParse(s, out long v))
                return v.ToString("N0", new CultureInfo("vi-VN"));

            return s;
        }

        // REALTIME FORMAT TIỀN
        private void AddEvents()
        {
            txtGiaNhap.TextChanged += (s, e) =>
            {
                if (txtGiaNhap.Focused)
                {
                    int pos = txtGiaNhap.SelectionStart;
                    txtGiaNhap.Text = FormatMoney(txtGiaNhap.Text);
                    txtGiaNhap.SelectionStart = txtGiaNhap.Text.Length;
                }
            };

            txtGiaBan.TextChanged += (s, e) =>
            {
                if (txtGiaBan.Focused)
                {
                    int pos = txtGiaBan.SelectionStart;
                    txtGiaBan.Text = FormatMoney(txtGiaBan.Text);
                    txtGiaBan.SelectionStart = txtGiaBan.Text.Length;
                }
            };
        }

        // ======================================
        //  KIỂM TRA DỮ LIỆU
        // ======================================
        private bool ValidateInput()
        {
            if (txtMaVL.Text == "" ||
                txtTenVL.Text == "" ||
                txtDonViTinh.Text == "" ||
                cbNCC.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return false;
            }

            return true;
        }

        // ======================================
        // CLICK BẢNG -> ĐỔ LÊN Ô
        // ======================================
        private void dgvVatLieu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow r = dgvVatLieu.Rows[e.RowIndex];

            txtMaVL.Text = r.Cells["MaVL"].Value.ToString();
            txtTenVL.Text = r.Cells["TenVL"].Value.ToString();
            txtDonViTinh.Text = r.Cells["DonViTinh"].Value.ToString();
            txtGiaNhap.Text = FormatMoney(r.Cells["GiaNhap"].Value.ToString());
            txtGiaBan.Text = FormatMoney(r.Cells["GiaBan"].Value.ToString());
            txtTonKho.Text = r.Cells["TonKho"].Value.ToString();
            cbNCC.Text = r.Cells["TenNCC"].Value.ToString();
        }

       

        private void ClearInput()
        {
            txtMaVL.Clear();
            txtTenVL.Clear();
            txtDonViTinh.Clear();
            txtGiaNhap.Clear();
            txtGiaBan.Clear();
            txtTonKho.Clear();
            cbNCC.SelectedIndex = -1;
        }

        private void UCVatLieu_Load(object sender, EventArgs e)
        {

        }

        private void txtMaVL_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTenVL_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDonViTinh_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtGiaNhap_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtGiaBan_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTonKho_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbNCC_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        // ======================================
        //  THÊM VẬT LIỆU
        // ======================================
        private void btnThem_Click_1(object sender, EventArgs e)
        {
       
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        INSERT INTO vatlieu 
                        (MaVL, TenVL, DonViTinh, GiaNhap, GiaBan, TonKho, MaNCC)
                        VALUES (@ma, @ten, @dvt, @gn, @gb, @tk, @ncc)
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaVL.Text);
                    cmd.Parameters.AddWithValue("@ten", txtTenVL.Text);
                    cmd.Parameters.AddWithValue("@dvt", txtDonViTinh.Text);
                    cmd.Parameters.AddWithValue("@gn", txtGiaNhap.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@gb", txtGiaBan.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@tk", txtTonKho.Text);
                    cmd.Parameters.AddWithValue("@ncc", cbNCC.SelectedValue);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Thêm vật liệu thành công!");
                LoadVatLieu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm vật liệu: " + ex.Message);
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {}

        // ======================================
        //  SỬA
        // ======================================
        private void btnSua_Click_1(object sender, EventArgs e)
        {
       
            if (!ValidateInput()) return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    string sql = @"
                        UPDATE vatlieu SET
                            TenVL=@ten,
                            DonViTinh=@dvt,
                            GiaNhap=@gn,
                            GiaBan=@gb,
                            TonKho=@tk,
                            MaNCC=@ncc
                        WHERE MaVL=@ma
                    ";

                    var cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaVL.Text);
                    cmd.Parameters.AddWithValue("@ten", txtTenVL.Text);
                    cmd.Parameters.AddWithValue("@dvt", txtDonViTinh.Text);
                    cmd.Parameters.AddWithValue("@gn", txtGiaNhap.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@gb", txtGiaBan.Text.Replace(".", ""));
                    cmd.Parameters.AddWithValue("@tk", txtTonKho.Text);
                    cmd.Parameters.AddWithValue("@ncc", cbNCC.SelectedValue);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Cập nhật thành công!");
                LoadVatLieu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa vật liệu: " + ex.Message);
            }
        }

        
        // ======================================
        // LÀM MỚI
        // ======================================
        private void btnLamMoi_Click_1(object sender, EventArgs e)
        {

            ClearInput();
        }

       
            // ======================================
            // XÓA
            // ======================================
        private void btnXoa_Click_1(object sender, EventArgs e)
        {

            if (MessageBox.Show("Bạn chắc chắn muốn xóa?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            try
            {
                using (var conn = Connect())
                {
                    conn.Open();

                    var cmd = new MySqlCommand("DELETE FROM vatlieu WHERE MaVL=@ma", conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaVL.Text);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Xóa thành công!");
                LoadVatLieu();
                ClearInput();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa vật liệu: " + ex.Message);
            }
        }
    }
  
}
